# 上调港股目标价到63港币，看好DeepSeek推动代工需求强劲增长

# 华泰研究

动态点评

2025年2月15日丨中国内地/中国香港

半导体

中芯国际 4Q 收入环比+1.7%，高于彭博一致预期，毛利率环比+2.1pct 到22.6%，高于公司18-20%指引上限。4Q24业绩主要亮点包括，1)ASP环比上升6%，好于同业，反映公司产品结构改善，2）中国区收入环比增长4.8%，占比环比上升2.7pct到89.1%，反映强劲的在地化需求。公司预计1Q25收入环比增长6-8%，高于彭博一致预期（-3.4%qoq）和同业指引。公司预计2025资本开支持平，高于之前下降的市场预期。2025年，我们看好中国客户在地化生产需求以及DeepSeek 商业化落地，推动业绩保持强劲增长。上调港股目标价至63港币（前值：32港币)，重申买入评级。

# 观点#1：本地化需求和DeepSeek或推动2025收入强劲增长

2024年，公司全年收入同比增长27%，其中中国区收入增长34%，美国区收入同比下降4.1%，主要反映中国芯片设计公司加快产业链本地化趋势的影响。展望2025年，公司预计1Q25收入环比增长6-8%，显著高于UMC（出货量环比持平且ASP环比中个位数下滑)，GFS（1Q25收入适度恢复同比增长）等同业指引。我们预计公司（H股）2025年收入增长21%（以美元计)。主要有以下驱动力：1）美国提高进口关税叠加国内刺激消费政策，有望推动消费电子企业补库存，2）中国设计企业加快供应链本地化步伐，以应对海外生产日益增长的不确定性，3)DeepSeek 的出现有望解决国内缺乏优秀算法的局面，下半年开始有望推动AI算力需求增长，成为中芯下一个增长动能。

# 观点#2：加大产能投入以应对长期需求增长

2024年，中芯国际资本开支73.3亿美元，同比-1.9%，设备折旧32.2亿美元，同比+20.8%，设备折旧占收入比40.1%。到2024年年底8英寸等效月产能94.8万片，和2023年底比新增14.2万片，目前全球排名第三。展望2025年，公司预计资本开支将与2024年持平，高于我们之前的下降33%的预期。我们认为，新的资本开支或主要用于满足快速增长的AI算力和车规级芯片需求。尽管折旧压力将在短期内继续增加，但公司有望通过提升产能利用率和丰富产品组合来缓解毛利率压力。

# 估值：上调港股目标价至63港币，A股至119人民币

我们看好消费电子刺激政策以及供应链本地化需求驱动，提升2025/2026年晶圆出货量预测，上修2025/2026年营收预测5.4%/9.6%至97.3/115.1亿美元，2025/2026/2027年营收预测为97.3/115.1/131.8 亿美元。对于A股报表，预计 2025/2026/2027年收入为705.7/834.6/955.3亿人民币。上调H股估值至3.0x2025PB（前值：1.53x)，上调港股目标价至HKD63（前值：HKD32)，基于2025BVPS2.68美元。上调A股目标价到119人民币，对应A/H溢价101%。我们认为公司是全球产业链重构主要受益者，看好公司通过积极投资把握中国企业在地化生产及DeepSeek等产业链机会。

风险提示：美国加强技术出口管制；8英寸和12英寸扩产不及预期。

981 HK 688981 CH 投资评级： 买入(维持) 买入(维持) 目标价： 港币：63.00 人民币：119.00 研究员 黄乐平，PhD SAC No. S0570521050001 huangleping@htsc.com SFC No. AUZ066 +(852) 3658 6000 研究员 谢春生 SAC No.S0570519080006 xiechunsheng@htsc.com SFC No. BQZ938 +(86) 21 2987 2036 研究员 陈旭东 SAC No. S0570521070004 chenxudong@htsc.com SFC No. BPH392 +(86) 21 2897 2228 联系人 于可熠 SAC No. S0570122120079 yukeyi@htsc.com SFC No. BVF938 +(86) 21 2897 2228

基本数据  

<table><tr><td>(港币/人民币)</td><td>981HK</td><td>688981CH</td></tr><tr><td>目标价</td><td>63.00</td><td>119.00</td></tr><tr><td>收盘价 (截至2月14日)</td><td>45.55</td><td>99.08</td></tr><tr><td>市值 (百万)</td><td>363,407</td><td>790,481</td></tr><tr><td>6个月平均日成交额 (百万)</td><td>4,048</td><td>6,630</td></tr><tr><td>52周价格范围</td><td>14.02-49.6040.33-104.98</td><td></td></tr><tr><td>BVPS</td><td>2.58</td><td>18.12</td></tr></table>

![](images/19ae19bcec13d3b006ac9cb2ad6cacc8cb23734be1e1b9913aeb50e14a850e4c.jpg)  
股价走势图  
资料来源：Wind

经营预测指标与估值   

<table><tr><td>会计年度</td><td>2023</td><td>2024</td><td>2025E</td><td>2026E</td><td>2027E</td></tr><tr><td>营业收入 (人民币百万)</td><td>45,250</td><td>57,796</td><td>70,567</td><td>83,458</td><td>95,530</td></tr><tr><td>+/-%</td><td>(13.09)</td><td>27.02</td><td>22.10</td><td>18.27</td><td>14.46</td></tr><tr><td>归属母公司净利润 (人民币百万)</td><td>4,823</td><td>3,699</td><td>3,284</td><td>4,311</td><td>5,648</td></tr><tr><td>+/-%</td><td>(50.35)</td><td>(45.40)</td><td>(11.21)</td><td>31.26</td><td>31.02</td></tr><tr><td>EPS(人民币，最新摊薄)</td><td>0.60</td><td>0.46</td><td>0.41</td><td>0.54</td><td>0.71</td></tr><tr><td>ROE (%)</td><td>4.60</td><td>2.42</td><td>2.16</td><td>2.72</td><td>3.49</td></tr><tr><td>PE (倍)</td><td>163.90</td><td>213.72</td><td>240.69</td><td>183.37</td><td>139.95</td></tr><tr><td>PB (倍)</td><td>5.42</td><td>5.29</td><td>5.10</td><td>4.87</td><td>4.90</td></tr><tr><td>EV EBITDA (倍)</td><td>24.64</td><td>22.23</td><td>20.83</td><td>18.97</td><td>24.67</td></tr></table>

资料来源：公司公告、华泰研究预测

# 代工行业4Q24业绩回顾与1Q25指引

中芯国际指引1Q25营收环比增长6%-8%，高于同市场的行业平均水平。联电指引晶圆出货量环比持平且ASP 环比中个位数下滑，Global foundries 指引1Q25收入适度恢复同比增长。毛利率方面，中芯国际预计1Q25毛利率为19%\~21%，中位数环比下降2.6个百分点，高于彭博一致预期的18.37%。

图表1：全球代工业绩及指引  

<table><tr><td rowspan=1 colspan=9>公司         1Q23         2Q23         3Q23         4Q23         1Q24        2Q24        3Q24         4Q24</td></tr><tr><td rowspan=1 colspan=1></td><td rowspan=1 colspan=8>A            A             A             A             A            A            A            A</td></tr><tr><td rowspan=1 colspan=1>收入环比增速</td><td rowspan=1 colspan=2></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td></td><td></td><td></td><td></td></tr><tr><td rowspan=1 colspan=1>台积电</td><td rowspan=1 colspan=1>-16.10%</td><td rowspan=1 colspan=1>-6.2%</td><td rowspan=1 colspan=1>10.2%</td><td rowspan=1 colspan=1>13.6%</td><td rowspan=1 colspan=1>-3.8%</td><td rowspan=1 colspan=2>10.3%        12.9%</td><td rowspan=1 colspan=1>14.2%</td></tr><tr><td rowspan=1 colspan=1>联电</td><td rowspan=1 colspan=1>-20.1%</td><td rowspan=1 colspan=1>3.8%</td><td rowspan=1 colspan=1>1.4%</td><td rowspan=1 colspan=1>3.7%</td><td rowspan=1 colspan=1>-0.6%</td><td rowspan=1 colspan=2>4.0%        6.5%</td><td rowspan=1 colspan=1>0.0%</td></tr><tr><td rowspan=1 colspan=1>世界先进</td><td rowspan=1 colspan=1>-14.5%</td><td rowspan=1 colspan=1>20.4%</td><td rowspan=1 colspan=1>7.1%</td><td rowspan=1 colspan=1>-8.4%</td><td rowspan=1 colspan=1>-0.4%</td><td rowspan=1 colspan=2>14.9%        6.7%</td><td rowspan=1 colspan=1>-7.4%</td></tr><tr><td rowspan=1 colspan=1>格罗方德</td><td rowspan=1 colspan=1>-12.4%</td><td rowspan=1 colspan=1>0.2%</td><td rowspan=1 colspan=1>0.4%</td><td rowspan=1 colspan=1>0.1%</td><td rowspan=1 colspan=1>-16.5%</td><td rowspan=1 colspan=2>5.4%        6.6%</td><td rowspan=1 colspan=1>5.2%</td></tr><tr><td rowspan=1 colspan=1>中芯国际*</td><td rowspan=1 colspan=1>-9.8%</td><td rowspan=1 colspan=1>6.7%</td><td rowspan=1 colspan=1>3.9%</td><td rowspan=1 colspan=1>3.6%</td><td rowspan=1 colspan=1>4.3%</td><td rowspan=1 colspan=1>8.6%</td><td rowspan=1 colspan=1>14.2%</td><td rowspan=1 colspan=1>1.7%</td></tr><tr><td rowspan=1 colspan=1>华虹半导体*</td><td rowspan=1 colspan=1>0.1%.</td><td rowspan=1 colspan=1>0.1%</td><td rowspan=1 colspan=1>-10.0%</td><td rowspan=1 colspan=1>-19.9%</td><td rowspan=1 colspan=1>1.0%</td><td rowspan=1 colspan=1>4.0%</td><td rowspan=1 colspan=1>10.0%</td><td rowspan=1 colspan=1>2.4%</td></tr><tr><td rowspan=1 colspan=1>毛利率</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>台积电</td><td rowspan=1 colspan=1>56.3%</td><td rowspan=1 colspan=1>54.1%</td><td rowspan=1 colspan=1>54.3%</td><td rowspan=1 colspan=1>53.0%</td><td rowspan=1 colspan=1>53.1%</td><td rowspan=1 colspan=1>53.2%</td><td rowspan=1 colspan=1>57.8%</td><td rowspan=1 colspan=1>59.0%</td></tr><tr><td rowspan=1 colspan=1>联电</td><td rowspan=1 colspan=1>35.5%</td><td rowspan=1 colspan=1>36.0%</td><td rowspan=1 colspan=1>35.9%</td><td rowspan=1 colspan=1>32.4%</td><td rowspan=1 colspan=1>30.9%</td><td rowspan=1 colspan=1>35.2%</td><td rowspan=1 colspan=1>33.8%</td><td rowspan=1 colspan=1>30.4%</td></tr><tr><td rowspan=1 colspan=1>世界先进</td><td rowspan=1 colspan=1>30.0%</td><td rowspan=1 colspan=1>30.0%</td><td rowspan=1 colspan=1>26.5%</td><td rowspan=1 colspan=1>23.0%</td><td rowspan=1 colspan=1>24.0%</td><td rowspan=1 colspan=1>26.0%</td><td rowspan=1 colspan=1>29.0%</td><td rowspan=1 colspan=1>27%-29%</td></tr><tr><td rowspan=1 colspan=1>格罗方德</td><td rowspan=1 colspan=1>28.5%</td><td rowspan=1 colspan=1>28.8%</td><td rowspan=1 colspan=1>28.6%</td><td rowspan=1 colspan=1>29.0%</td><td rowspan=1 colspan=1>25.4%</td><td rowspan=1 colspan=1>24.2%</td><td rowspan=1 colspan=1>23.8%</td><td rowspan=1 colspan=1>24.5%</td></tr><tr><td rowspan=1 colspan=1>中芯国际*</td><td rowspan=1 colspan=1>20.8%</td><td rowspan=1 colspan=1>20.3%</td><td rowspan=1 colspan=1>19.8%</td><td rowspan=1 colspan=1>16.4%</td><td rowspan=1 colspan=1>13.7%</td><td rowspan=1 colspan=1>13.9%</td><td rowspan=1 colspan=1>20.5%</td><td rowspan=1 colspan=1>22.6%</td></tr><tr><td rowspan=1 colspan=1>华虹半导体*</td><td rowspan=1 colspan=1>32.1%.</td><td rowspan=1 colspan=1>27.7%</td><td rowspan=1 colspan=1>16.1%</td><td rowspan=1 colspan=1>4.0%</td><td rowspan=1 colspan=1>6.4%</td><td rowspan=1 colspan=1>10.5%</td><td rowspan=1 colspan=1>12.2%</td><td rowspan=1 colspan=1>11.4%</td></tr><tr><td rowspan=1 colspan=1>产能利用率</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>台积电</td><td rowspan=1 colspan=1>N.A</td><td rowspan=1 colspan=1>N.A.</td><td rowspan=1 colspan=1>N.A</td><td rowspan=1 colspan=1>N.A</td><td rowspan=1 colspan=1>N.A</td><td rowspan=1 colspan=1>N.A</td><td rowspan=1 colspan=1>N.A</td><td rowspan=1 colspan=1>N.A</td></tr><tr><td rowspan=1 colspan=1>联电</td><td rowspan=1 colspan=1>70.0%</td><td rowspan=1 colspan=1>71.0%</td><td rowspan=1 colspan=1>67.0%</td><td rowspan=1 colspan=1>66.0%</td><td rowspan=1 colspan=1>65.0%</td><td rowspan=1 colspan=1>68.0%</td><td rowspan=1 colspan=1>71.0%</td><td rowspan=1 colspan=1>70.0%</td></tr><tr><td rowspan=1 colspan=1>世界先进</td><td rowspan=1 colspan=1>N.A</td><td rowspan=1 colspan=1>N.A</td><td rowspan=1 colspan=1>N.A</td><td rowspan=1 colspan=1>N.A</td><td rowspan=1 colspan=1>N.A</td><td rowspan=1 colspan=1>N.A</td><td rowspan=1 colspan=1>NA</td><td rowspan=1 colspan=1>N.A</td></tr><tr><td rowspan=1 colspan=1>格罗方德</td><td rowspan=1 colspan=1>N.A</td><td rowspan=1 colspan=1>N.A</td><td rowspan=1 colspan=1>N.A</td><td rowspan=1 colspan=1>N.A</td><td rowspan=1 colspan=1>N.A</td><td rowspan=1 colspan=1>N.A</td><td rowspan=1 colspan=1>N.A</td><td rowspan=1 colspan=1>N.A</td></tr><tr><td rowspan=1 colspan=1>中芯国际*</td><td rowspan=1 colspan=1>68.1%</td><td rowspan=1 colspan=1>78.3%</td><td rowspan=1 colspan=1>77.1%</td><td rowspan=1 colspan=1>76.8%</td><td rowspan=1 colspan=1>80.8%</td><td rowspan=1 colspan=1>85.2%</td><td rowspan=1 colspan=1>90.4%</td><td rowspan=1 colspan=1>85.5%</td></tr><tr><td rowspan=1 colspan=1>华虹半导体*</td><td rowspan=1 colspan=1>103.5%</td><td rowspan=1 colspan=1>102.7%</td><td rowspan=1 colspan=1>86.8%</td><td rowspan=1 colspan=1>84.1%</td><td rowspan=1 colspan=1>91.7%</td><td rowspan=1 colspan=1>97.9%</td><td rowspan=1 colspan=1>105.3%</td><td rowspan=1 colspan=1>103.2%</td></tr><tr><td rowspan=1 colspan=1>ASP （USD,等效8寸）</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>台积电</td><td rowspan=1 colspan=1>2.303</td><td rowspan=1 colspan=1>2.389</td><td rowspan=1 colspan=1>2.646</td><td rowspan=1 colspan=1>2949</td><td rowspan=1 colspan=1>2768</td><td rowspan=1 colspan=1>2961</td><td rowspan=1 colspan=1>3129</td><td rowspan=1 colspan=1>3,490</td></tr><tr><td rowspan=1 colspan=1>联电</td><td rowspan=1 colspan=1>975</td><td rowspan=1 colspan=1>988</td><td rowspan=1 colspan=1>989</td><td rowspan=1 colspan=1>1,026</td><td rowspan=1 colspan=1>937</td><td rowspan=1 colspan=1>937</td><td rowspan=1 colspan=1>935</td><td rowspan=1 colspan=1>935</td></tr><tr><td rowspan=1 colspan=1>世界先进</td><td rowspan=1 colspan=1>650</td><td rowspan=1 colspan=1>619</td><td rowspan=1 colspan=1>608</td><td rowspan=1 colspan=1>644</td><td rowspan=1 colspan=1>642</td><td rowspan=1 colspan=1>668</td><td rowspan=1 colspan=1>600</td><td rowspan=1 colspan=1>624</td></tr><tr><td rowspan=1 colspan=1>格罗方德</td><td rowspan=1 colspan=1>1393</td><td rowspan=1 colspan=1>1274</td><td rowspan=1 colspan=1>1274</td><td rowspan=1 colspan=1>1315</td><td rowspan=1 colspan=1>1320</td><td rowspan=1 colspan=1>1273</td><td rowspan=1 colspan=1>1267</td><td rowspan=1 colspan=1>1253</td></tr><tr><td rowspan=1 colspan=1>中芯国际*</td><td rowspan=1 colspan=1>1,168</td><td rowspan=1 colspan=1>1,006</td><td rowspan=1 colspan=1>961</td><td rowspan=1 colspan=1>931</td><td rowspan=1 colspan=1>907</td><td rowspan=1 colspan=1>836</td><td rowspan=1 colspan=1>966</td><td rowspan=1 colspan=1>1025</td></tr><tr><td rowspan=1 colspan=1>华虹半导体*</td><td rowspan=1 colspan=1>605</td><td rowspan=1 colspan=1>560</td><td rowspan=1 colspan=1>500</td><td rowspan=1 colspan=1>459</td><td rowspan=1 colspan=1>426</td><td rowspan=1 colspan=1>410</td><td rowspan=1 colspan=1>415</td><td rowspan=1 colspan=1>423</td></tr></table>

注：标\*公司为华泰覆盖；公司指引来自各公司公告资料来源：公司公告，Bloomberg，Wind，华泰研究

![](images/4036a99dedd74efb3572667d0b9bc234be8b881fb880f1e5dc82cb587ef2deec.jpg)  
图表2：代工厂股价相对涨跌幅  
注：截至2月14日收盘价，2022年1月1日日收盘价记作100资料来源：Factset，华泰研究

# 中芯国际4Q24业绩回顾

# 4Q24毛利率超一致预期

中芯国际 4Q24营收为22.1亿美元（环比增长1.7%，同比增长31.5%)，高于彭博一致预期。毛利率为22.6%（环比增长2.1pct，同比增长6.2pct)，好于其指引（18%-20%）和彭博一致预期（19.1%)。产能利用率为85.5%（环比下降4.9个百分点，同比增长8.7个百分点)。

图表3：中芯国际季度业绩及指引  

<table><tr><td>美元百万</td><td></td><td>1Q24</td><td>2Q24</td><td>3Q24</td><td>4Q24</td><td>1Q25</td><td>4Q24</td><td>4Q24</td><td>1Q25</td><td>1Q25</td></tr><tr><td></td><td></td><td>A</td><td>A</td><td>A</td><td>A</td><td>E</td><td>CON</td><td>Guidance</td><td>CON</td><td>Guidance</td></tr><tr><td>8寸</td><td></td><td>329</td><td>329</td><td>329</td><td>328</td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>12寸-成熟制程</td><td></td><td>186</td><td>196</td><td>217</td><td>236</td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>12寸-先进制程</td><td></td><td>30</td><td>30</td><td>30</td><td>30</td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>产能总计(千片)</td><td></td><td>815</td><td>837</td><td>884</td><td>925</td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td>同比增长</td><td>1.1%</td><td>2.8%</td><td>5.6%</td><td>4.6%</td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>稼动率</td><td></td><td>80.8%</td><td>85.2%</td><td>90.4%</td><td>85.5%</td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>收入</td><td></td><td>1,750</td><td>1,901</td><td>2,171</td><td>2,207</td><td>2,362</td><td>2,197</td><td>2171-2214</td><td></td><td>2,132 2340-2390</td></tr><tr><td rowspan="3">晶圆单价</td><td>环比增长</td><td>4.3%</td><td>8.6%</td><td>14.2%</td><td>1.7%</td><td>7.0%</td><td>1.2%</td><td>0%~2%</td><td> -3.4% 6%~8%</td><td></td></tr><tr><td></td><td>907</td><td>836</td><td>966</td><td>1,025</td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>环比增长</td><td>-2.6%</td><td>-7.8%</td><td>15.5%</td><td>6.1%</td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>营业成本</td><td></td><td>(1.510)</td><td>(1,636)</td><td>(1,727)</td><td>(1,708)</td><td>(1,889)</td><td></td><td></td><td></td><td></td></tr><tr><td>毛利</td><td></td><td>240</td><td>265</td><td>444</td><td>499</td><td>472</td><td></td><td></td><td></td><td></td></tr><tr><td>EBITDA</td><td></td><td>887</td><td>1,056</td><td>1,157</td><td>1,280</td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td>同比增长</td><td>-12.3%</td><td>19.1%</td><td>9.6%</td><td>10.6%</td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>营业利润</td><td></td><td>2</td><td>87</td><td>170</td><td>214</td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td>同比增长</td><td>-98%</td><td>3522%</td><td>95%</td><td>26%</td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>税前收益</td><td></td><td>74</td><td>187</td><td>243</td><td>355</td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>所得税</td><td></td><td>(11)</td><td>(15)</td><td>(20)</td><td>(84)</td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>少数股东权益</td><td></td><td>8</td><td>（8）</td><td>（74)</td><td>(163)</td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>归属母公司净利</td><td></td><td>72</td><td>165</td><td>149</td><td>108</td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td>同比增长</td><td>-58.9%</td><td>129.2%</td><td>-9.6%</td><td> -27.7%</td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>2,235</td><td>2,252</td><td>1,179</td><td>1,660</td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>（746）</td><td>(797)</td><td>(831)</td><td>(849)</td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>比率 (%)</td><td></td><td>6.5%</td><td>6.9%</td><td>4.2%</td><td>2.2%</td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>毛利率</td><td></td><td>13.7%</td><td>13.9%</td><td>20.5%</td><td>22.6%</td><td>20.0%</td><td>19.1%</td><td>18%~20%</td><td>18.4% 19%~21%</td><td></td></tr><tr><td>EBITDA利润率</td><td></td><td>50.7%</td><td>55.5%</td><td>53.3%</td><td>58.0%</td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>营业利润率</td><td></td><td>0.1%</td><td>4.6%</td><td>7.8%</td><td>9.7%</td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>税前收益率</td><td></td><td>4.3%</td><td>9.8%</td><td>11.2%</td><td>16.1%</td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>净利率</td><td></td><td>4.1%</td><td>8.7%</td><td>6.9%</td><td>4.9%</td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>净资产收益率</td><td></td><td>3.7%</td><td>2.5%</td><td>2.7%</td><td>2.4%</td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>每股净资产</td><td></td><td>2.53</td><td>2.53</td><td>2.54</td><td>2.59</td><td></td><td></td><td></td><td></td><td></td></tr></table>

注：图中前四行为产能指标，单位为千片/月，产能合计为8寸等效产能；图中晶圆单价单位为美元资料来源：公司财报，Wind，华泰研究

# 4Q24业绩说明会要点

1)营收和毛利率：据中芯国际，4Q24公司季度新增2.8万片12英寸产能，产品组合优化，ASP 环比上升6%，抵消了出货下降对收入影响和折旧上升对毛利率的影响，公司4Q24实现营收 22.07亿美元(环比增长1.7%,同比增长31.5%),毛利率 22.6%(环比增长2.1pct,同比增长6.2pct)。2024年，半导体市场整体复苏，库存恢复健康，主要产业向国内产业链快速切换，公司加快产能扩充节奏，提升了平台完备性，国内客户新产品快速验证并上量，实现收入80.3亿美元。

2）晶圆销售均价和毛利率：4Q24公司销售均价环比增长15.5%至966美元，主因12英寸出货比例上升，产品组合优化调整。

3）产能和资本开支：公司产能持续爬坡。4Q24末其整体产能达948kwpm（环比增长  
63kwpm)，产能利用率为85.5%（环比下降4.9pct，同比增长8.7pct)。4Q24 资本支出为  
16.6亿美元。

# 4）分板块业绩情况：

4Q24中芯国际8英寸营收占晶圆总营收的19.4%（同比下降6.4个百分点，环比下降2.1个百分点)，12英寸营收占晶圆总营收的80.6%（同比上升6.4个百分点，环比上升2.1个百分点）。

按应用划分，公司4Q24工业和汽车/连接和物联网/消费电子/电脑和平板/智能手机营收占总营收的8.2%/8.3%/40.2%/19.1%/24.2%。按销售地域划分，公司4Q24中国地区营收占比为89.1%，欧亚地区2.0%，美国8.9%。

图表4：收入明细 (按技术节点划分)  

<table><tr><td>（美元百万）</td><td></td><td>1Q24 A</td><td>2Q24 3Q24 A</td><td>4Q24 A</td><td>A</td><td>2022 A</td><td>2023 A</td><td>2024 A</td><td>2025E (Huatai)</td><td>2026E (Huatai)</td><td>2027E (Huatai)</td></tr><tr><td>收入</td><td></td><td>1,750</td><td>1,901</td><td>2,171</td><td>2,207</td><td>7,273</td><td>6,322</td><td>8,030</td><td>9,733</td><td>11,511</td><td>13,177</td></tr><tr><td></td><td>环比增长</td><td>4.3%</td><td>8.6%</td><td>14.2%</td><td>1.7%</td><td>34%</td><td>-13%</td><td>27%</td><td>21%</td><td>18%</td><td>14%</td></tr><tr><td>按制程分类</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>12&quot;先进制程(12/14nm)</td><td></td><td>291</td><td>309</td><td>475</td><td>465</td><td>858</td><td>1,074</td><td>1,429</td><td>2,427</td><td>3,520</td><td>4,390</td></tr><tr><td>12&quot;成熟制程(28-90nm)</td><td></td><td>939</td><td>991</td><td>1,134</td><td>1,181</td><td>3,655</td><td>3,199</td><td>4,356</td><td>4,987</td><td>5,672</td><td>6,467</td></tr><tr><td>8&quot; (0.11um+)</td><td></td><td>397</td><td>466</td><td>441</td><td>396</td><td>2,222</td><td>1,522</td><td>1,700</td><td>1,775</td><td>1,775</td><td>1,775</td></tr><tr><td>%chg QoQ</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>12&quot;先进制程(12/14nm)</td><td></td><td>317.4%</td><td>6.2%</td><td>53.5%</td><td>-2.0%</td><td>24%</td><td>25%</td><td>33%</td><td>70%</td><td>45%</td><td>25%</td></tr><tr><td>12&quot;成熟制程(28-90nm)</td><td></td><td>-13.6%</td><td>5.5%</td><td>14.5%</td><td>4.1%</td><td>38%</td><td>-12%</td><td>36%</td><td>14%</td><td>14%</td><td>14%</td></tr><tr><td>8&quot; (0.11um+)</td><td></td><td>-1.3%</td><td>17.4%</td><td>-5.5%</td><td>-10.1%</td><td>19%</td><td>-32%</td><td>12%</td><td>4%</td><td>0%</td><td>0%</td></tr><tr><td>产能利用率</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>12&quot;先进制程(12/14nm)</td><td></td><td></td><td></td><td></td><td></td><td>100.0%</td><td>100.0%</td><td>100.0%</td><td>100.0%</td><td>100.0%</td><td>105.0%</td></tr><tr><td>12&quot;成熟制程(28-90nm)</td><td></td><td></td><td></td><td></td><td></td><td>88.0%</td><td>73.0%</td><td>82.0%</td><td>80.0%</td><td>80.0%</td><td>80.0%</td></tr><tr><td>8&quot;(0.11um+)</td><td></td><td></td><td></td><td></td><td></td><td>83.0%</td><td>68.0%</td><td>90.0%</td><td>95.0%</td><td>95.0%</td><td>95.0%</td></tr><tr><td>营收占比</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>12&quot;先进制程(12/14nm)</td><td></td><td></td><td></td><td></td><td></td><td>11.8% 50.3%</td><td>17.0%</td><td>17.8%</td><td>24.9%</td><td>30.6%</td><td>33.3%</td></tr><tr><td>12&quot;成熟制程(28-90nm)</td><td></td><td></td><td></td><td></td><td></td><td>30.5%</td><td>50.6% 24.1%</td><td>54.2% 21.2%</td><td>51.2% 18.2%</td><td>49.3%</td><td>49.1%</td></tr><tr><td>8&quot;(0.11um+)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>15.4%</td><td>13.5%</td></tr></table>

资料来源：公司公告，Wind，华泰研究预测

# 1Q25与2025年展望

1）营收和毛利率：中芯国际指引1Q25营收环比增长6%-8%，中位数同比+35%，高于彭博一致预期的环比增速(-3.4%)；毛利率指引19%-21%，中位数环比下降2.6pct，高于彭博一致预期的18.37%。

2）终端市场需求：公司认为2025年，除了AI继续高速成长外，各领域需求持平或温和增长。公司看到：1）汽车等产业链向国产链转移切换，从验证阶段进入体量阶段，部分产品正式量产；2）政策刺激下消费互联手机补单急单较多，一季度淡季不淡，但下半年仍存在不确定性。

3）2025公司展望：1）公司预计2025折旧年增两成，将以持续盈利为目标，通过提升产能利用率对抗折旧，丰富产品组合对抗周期；2）行业同质化竞争，产能结构性过剩，公司会增加新产品对抗降价压力，不主动降价，但必要时会和战略客户一起直面价格竞争，以保持市场份额和竞争优势；3）汽车产品线验证中，未来希望提升至10%营业额。

# 盈利预测调整

中芯国际H股：考虑到1Q25公司需求指引乐观，我们上修2025/2026年晶圆出货量预测，2025/2026/2027年营收预测为97.3/115.1/131.8亿美元。考虑到 2025年资本开支高于此前预期，下修 2025-2026 年净利润，预计 2025/2026/2027年归母净利润为 5.38/6.98/8.64亿美元。

对于中芯国际A股：我们预计 2025/2026/2027年营收为705.7/834.6/955.3亿人民币，2025/2026/2027年归母净利润为32.8/43.1/56.5亿人民币。（基于汇率换算：1USD=7.25RMB)

图表5：中芯国际业绩预测调整  

<table><tr><td>美元百万</td><td></td><td>2022</td><td>2023</td><td>2024A</td><td>2025E</td><td>2026E</td><td>2027E</td><td>2025E</td><td>2026E</td><td>2025E</td><td>2026E</td></tr><tr><td></td><td></td><td>A</td><td>A</td><td>A</td><td> (Huatai)</td><td>(Huatai)</td><td> (Huatai)</td><td>(OLD)</td><td>(OLD)</td><td>Diff.</td><td>Diff.</td></tr><tr><td>8寸</td><td></td><td>327</td><td>374</td><td>373</td><td>373</td><td>373</td><td>373</td><td></td><td></td><td></td><td></td></tr><tr><td>12寸-成熟制程</td><td></td><td>152</td><td>172</td><td>226</td><td>266</td><td>302</td><td>352</td><td></td><td></td><td></td><td></td></tr><tr><td>12寸-先进制程</td><td></td><td>20</td><td>30</td><td>30</td><td>50</td><td>70</td><td>90</td><td></td><td></td><td></td><td></td></tr><tr><td>产能总计(千片)</td><td></td><td>714</td><td>828</td><td>948</td><td>1,083</td><td>1,209</td><td>1,366</td><td></td><td></td><td></td><td></td></tr><tr><td></td><td>同比增长</td><td>15%</td><td>16%</td><td>14%</td><td>14%</td><td>12%</td><td>13%</td><td></td><td></td><td></td><td></td></tr><tr><td>稼动率</td><td></td><td>92%</td><td>75%</td><td>78%</td><td>84%</td><td>87%</td><td>88%</td><td></td><td></td><td></td><td></td></tr><tr><td>收入</td><td></td><td>7,273</td><td>6,322</td><td>8,030</td><td>9,733</td><td>11,511</td><td>13,177</td><td>9,233</td><td>10,499</td><td>5.4%</td><td>9.6%</td></tr><tr><td></td><td>环比增长</td><td>34%</td><td>-13%</td><td>27%</td><td>21%</td><td>18%</td><td>14%</td><td></td><td></td><td></td><td></td></tr><tr><td>晶圆单价</td><td></td><td>948.9</td><td>987.7</td><td>933.2</td><td>893.3</td><td>914.4</td><td>930.9</td><td>914</td><td>911</td><td> -2.2%</td><td>0.4%</td></tr><tr><td></td><td>环比增长</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>营业成本</td><td></td><td>(4,512)</td><td>(5,104)</td><td>(6,582)</td><td>(7,925)</td><td>(9,105)</td><td>(10,195)</td><td></td><td></td><td></td><td></td></tr><tr><td>毛利</td><td></td><td>2,762</td><td>1,218</td><td>1,448</td><td>1,808</td><td>2,406</td><td>2,982</td><td></td><td></td><td></td><td></td></tr><tr><td>EBITDA</td><td></td><td>4,262</td><td>3,328</td><td>3,834</td><td>4,523</td><td>5,198</td><td>5.839</td><td></td><td></td><td></td><td></td></tr><tr><td></td><td>同比增长</td><td>18%</td><td>-22%</td><td>15%</td><td>18%</td><td>15%</td><td>12%</td><td></td><td></td><td></td><td></td></tr><tr><td>营业利润</td><td></td><td>1,836</td><td>358</td><td>474</td><td>540</td><td>820</td><td>1,109</td><td></td><td></td><td></td><td></td></tr><tr><td></td><td>同比增长</td><td>32%</td><td>-81%</td><td>32%</td><td>14%</td><td>52%</td><td>35%</td><td></td><td></td><td></td><td></td></tr><tr><td>税前收益</td><td></td><td>2,214</td><td>1,187</td><td>860</td><td>938</td><td>1,218</td><td>1,507</td><td></td><td></td><td></td><td></td></tr><tr><td>所得税</td><td></td><td>(16)</td><td>(63)</td><td>(130)</td><td>(141)</td><td>(184)</td><td>(227)</td><td></td><td></td><td></td><td></td></tr><tr><td>少数股东权益</td><td></td><td>(380)</td><td>(222)</td><td>(237)</td><td>(259)</td><td>(336)</td><td>(416)</td><td></td><td></td><td></td><td></td></tr><tr><td>归属母公司净利</td><td></td><td>1,818</td><td>903</td><td>493</td><td>538</td><td>698</td><td>864</td><td>727</td><td>1,069</td><td>-26.0%</td><td>-34.7%</td></tr><tr><td></td><td>同比增长</td><td>7%</td><td>-50%</td><td>-45%</td><td>9%</td><td>30%</td><td>24%</td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>6,351</td><td>7,466</td><td>7,326</td><td>7,500</td><td>7,500</td><td>7.500</td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>(2.271)</td><td>(2,667)</td><td>(3,223)</td><td>(3,846)</td><td>(4,241)</td><td>(4,593)</td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>22%</td><td>17%</td><td>21%</td><td>19%</td><td>10%</td><td>8%</td><td></td><td></td><td></td><td></td></tr><tr><td>比率 (%)</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>毛利率</td><td></td><td>38.0%</td><td>19.3%</td><td>18.0%</td><td>18.6%</td><td>20.9%</td><td>22.6%</td><td>20.4%</td><td>24.0%</td><td>0.0pct</td><td>-0.3pct</td></tr><tr><td>EBITDA利润率</td><td></td><td>58.6%</td><td>52.6%</td><td>47.7%</td><td>46.5%</td><td>45.2%</td><td>44.3%</td><td></td><td></td><td></td><td></td></tr><tr><td>营业利润率</td><td></td><td>25.2%</td><td>5.7%</td><td>5.9%</td><td>5.5%</td><td>7.1%</td><td>8.4%</td><td></td><td></td><td></td><td></td></tr><tr><td>税前收益率</td><td></td><td>30.4%</td><td>18.8%</td><td>10.7%</td><td>9.6%</td><td>10.6%</td><td>11.4%</td><td></td><td></td><td></td><td></td></tr><tr><td>净利率</td><td></td><td>25.0%</td><td>14.3%</td><td>6.1%</td><td>5.5%</td><td>6.1%</td><td>6.6%</td><td></td><td></td><td></td><td></td></tr><tr><td>净资产收益率</td><td></td><td>9.5%</td><td>4.5%</td><td>2.4%</td><td>2.5%</td><td>3.2%</td><td>3.8%</td><td></td><td></td><td></td><td></td></tr><tr><td>每股净资产</td><td></td><td>2.42</td><td>2.54</td><td>2.60</td><td>2.68</td><td>2.81</td><td>2.81</td><td></td><td></td><td></td><td></td></tr></table>

注：图中前四行为产能指标，单位为千片/月，产能合计为8寸等效产能；图中晶圆单价单位为美元资料来源：公司财报，Wind，华泰研究预测

# 估值方法

我们认为中芯国际H股的估值主要取决于其基本面（例如营收增长、毛利率和EBITDA 利润率）以及经由沪港通机制的南向资金持有量。

如下图所示，中芯国际H股的交易价格对应0.7-2.7倍1年期远期PB（通过使用IPO后的股票进行标准化)。中芯国际在2020年4月上调2Q20 指引后，公司股价持续上涨，并且投资者对A股IPO定价溢价的预期甚至导致2020年6月H股股价快速上涨（超过4倍投前 PB)。然而，2020年11月中芯国际被美国商务部列入实体清单，公司在产能扩张方面面临不确定性，引发市场担忧，导致股价大幅下调。

![](images/7fe40215495d8bf9593fef49d688d18a2349287a200eb6f0eecce18287e847a0.jpg)  
图表6：中芯国际H股历史股价对应0.7-2.7倍PB  
资料来源：公司公告，Wind，华泰研究

![](images/35d5458405f9caea9e818dd4fae8594b3ef2c7dee762869401ba576ef59394e4.jpg)  
图表7：南向资金成为中芯国际-H股价上涨的影响因素  
资料来源：公司信息，Wind，华泰研究

自2020年以来，中芯国际H股股价在0.7-2.7倍BVPS区间震荡。我们认为公司是全球产业链重构的主要受益者之一。看好公司通过积极投资把握1）中国企业在地化生产，以及2)DeepSeek等产业链机会。我们估值倍数上调至3.0倍（前值1.53xPB)，基于2025年预测 BPS（2.68美元)，上调H股目标价至63港币（前值：32.00 港币）。基于A股对H股溢价101%（截至2025年2月14日收盘的三年AH溢价率均值)，我们给予A股目标价人民币119元（前值：117.17元）。

图表8：可比公司估值表  

<table><tr><td colspan="3"></td><td rowspan="2">股价</td><td rowspan="2"></td><td colspan="2">市值 PE(x)</td><td colspan="2">PB(x)</td><td colspan="2">ROE(%)</td></tr><tr><td>公司</td><td>交易币种</td><td>财报币种</td><td>(USDmn)</td><td>2025E</td><td>2026E</td><td>2025E</td><td>2026E 2025E</td><td>2026E</td></tr><tr><td>股票 2330 TT</td><td>台积电</td><td>TWD</td><td>TWD</td><td>1060.00</td><td>1,046,773.98</td><td>18.33</td><td>15.36</td><td>5.38</td><td>4.16</td><td>29.30</td><td>27.10</td></tr><tr><td>2303TT</td><td>联电</td><td>TWD</td><td>TWD</td><td>41.40</td><td>14,772.64</td><td>11.68</td><td>10.04</td><td>1.33</td><td>1.27</td><td>11.40</td><td>12.70</td></tr><tr><td>5347 TT</td><td>世界先进</td><td>TWD</td><td>TWD</td><td>87.20</td><td>5,055.26</td><td>19.07</td><td>18.54</td><td>2.97</td><td>2.81</td><td>14.30</td><td>15.60</td></tr><tr><td>TSEM US</td><td>高塔半导体 USD</td><td></td><td>USD</td><td>48.21</td><td>5,351.49</td><td>22.47</td><td>17.88</td><td>na</td><td>na</td><td>11.49</td><td>10.40</td></tr><tr><td>GFS US</td><td>格罗方德</td><td>USD</td><td>USD</td><td>42.82</td><td>23,664.67</td><td>25.21</td><td>17.52</td><td>2.02</td><td>1.84</td><td>8.00</td><td>10.50</td></tr><tr><td>1347 HK</td><td>华虹半导体 HKD</td><td></td><td>USD</td><td>25.65</td><td>6,979.08</td><td>32.34</td><td>22.93</td><td>0.93</td><td>0.89</td><td>2.90</td><td>3.90</td></tr><tr><td rowspan="2"></td><td>平均</td><td></td><td></td><td></td><td></td><td>21.52</td><td>17.05</td><td>2.53</td><td>2.20</td><td>12.90</td><td>13.37</td></tr><tr><td>中位数</td><td></td><td></td><td></td><td></td><td>20.77</td><td>17.70</td><td>2.02</td><td>1.84</td><td>11.45</td><td>11.60</td></tr><tr><td>981HK</td><td>中芯国际</td><td>HKD</td><td>USD</td><td>45.55</td><td>62,514.36</td><td>103.01</td><td>78.47</td><td>2.18</td><td>2.08</td><td>2.16</td><td>2.72</td></tr></table>

注：股价为2025年2月14日收盘价；可比公司预测数据来自彭博一致预期。美元港币汇率按7.78计，港币人民币汇率按0.93计资料来源：Bloomberg，华泰研究预测

![](images/2381606404ad5fb9fa5b7bd2d60bc75665632736f4f406bbf7b1b2179788f83a.jpg)  
图表9：中芯国际A股上市以来AH溢价率（%)  
资料来源：Wind，华泰研究

![](images/27065918e5fdb3d1eb8f58af7a8dd5d80a3ed9c38561321ee119d1a01d9bb47c.jpg)  
图表10：代工厂:PB vs ROE(2025E)

注：PB和ROE为2025E预测，中芯国际为华泰预测，其余公司为彭博一致预期，  
截至2月12日收盘  
资料来源：公司财报，彭博，华泰研究  
注：PB和ROE为2026E预测，中芯国际为华泰预测，其余公司为彭博一致预期，  
截至2月12日收盘  
资料来源：公司财报，彭博，华泰研究

![](images/e7d7d7ea59b632875417b4e99ec17bc78027476e81572fb2f3e5aa7b81691ae3.jpg)  
图表11:代工厂:PB vs ROE(2026E)

# 风险提示

1)中美贸易摩擦及美国加强技术出口管制。美国在2020年将中芯国际列入其“实体清单”，限制对该公司的美国技术出口。我们认为，如果美国继续收紧技术出口，中芯国际的制造能力可能面临不确定性。

2）成熟制程工艺（8英寸和12英寸）的扩产速度不及我们的预期。美国的技术出口限制可能导致中芯国际8英寸和12英寸成熟制程的产能扩张不及我们的预期。

![](images/af4e11d6b48a1a810e815c323a955369d76d6181a1ad17c83a83ee750832b7fd.jpg)  
图表12：中芯国际PE-Bands  
资料来源：Wind、华泰研究

![](images/b8c99d75eadf49cf48fbd751c788dffc51d496c00b6546d138f4ddcc5f94d747.jpg)  
图表13：中芯国际PB-Bands  
资料来源：Wind、华泰研究

# 盈利预测

资产负债表  

<table><tr><td>会计年度 (人民币百万)</td><td>2023</td><td>2024</td><td>2025E</td><td>2026E</td><td>2027E</td></tr><tr><td>流动资产</td><td>96,574</td><td>106,271</td><td>86,962</td><td>99,789</td><td>84,053</td></tr><tr><td>现金</td><td>51,235</td><td>45,748</td><td>20,818</td><td>29,075</td><td>9,789</td></tr><tr><td>应收账款</td><td>3,501</td><td>6,091</td><td>10,875</td><td>11,600</td><td>11,600</td></tr><tr><td>其他应收账款</td><td>160.06</td><td>140.59</td><td>140.59</td><td>140.59</td><td>140.59</td></tr><tr><td>预付账款</td><td>751.86</td><td>422.96</td><td>422.96</td><td>422.96</td><td>422.96</td></tr><tr><td>存货</td><td>19,378</td><td>21,266</td><td>25,826</td><td>29,671</td><td>33,220</td></tr><tr><td>其他流动资产</td><td>21,547</td><td>32,602</td><td>28,880</td><td>28,880</td><td>28,880</td></tr><tr><td>非流动资产</td><td>241,889</td><td>247,119</td><td>277,257</td><td>287,138</td><td>282,484</td></tr><tr><td>长期投资</td><td>14,484</td><td>9,081</td><td>10,188</td><td>10,551</td><td>10,380</td></tr><tr><td>固定投资</td><td>92,432</td><td>201,937</td><td>219,257</td><td>229,138</td><td>246,234</td></tr><tr><td>无形资产</td><td>3,344</td><td>3,133</td><td>3,133</td><td>3,133</td><td>3,133</td></tr><tr><td>其他非流动资产</td><td>131,629</td><td>32,969</td><td>44,679</td><td>44,316</td><td>22,737</td></tr><tr><td>资产总计</td><td>338,463</td><td>353,391</td><td>364,219</td><td>386,927</td><td>366,537</td></tr><tr><td>流动负债</td><td>52,614</td><td>62,968</td><td>57,577</td><td>64,347</td><td>63,578</td></tr><tr><td>短期借款</td><td>3,398</td><td>58,277</td><td>3,832</td><td>4,132</td><td>4,432</td></tr><tr><td>应付账款</td><td>4,940</td><td>4,388</td><td>3,000</td><td>3,000</td><td>3,000</td></tr><tr><td>其他流动负债</td><td>44,277</td><td>303.44</td><td>50,745</td><td>57,216</td><td>56,146</td></tr><tr><td>非流动负债</td><td>67,379</td><td>61,331</td><td>69,152</td><td>76,402</td><td>57,044</td></tr><tr><td>长期借款</td><td>59,032</td><td>57,781</td><td>65,527</td><td>72,777</td><td>53,419</td></tr><tr><td>其他非流动负债</td><td>8,347</td><td>3,549</td><td>3,625</td><td>3,625</td><td>3,625</td></tr><tr><td>负债合计</td><td>119,993</td><td>124,299</td><td>126,728</td><td>140,749</td><td>120,621</td></tr><tr><td>少数股东权益</td><td>75,994</td><td>80,912</td><td>82,581</td><td>83,696</td><td>84,672</td></tr><tr><td>股本</td><td>225.51</td><td>229.35</td><td>229.35</td><td>229.35</td><td>229.35</td></tr><tr><td>资本公积</td><td>102,332</td><td>103,431</td><td>101,769</td><td>102,511</td><td>102,570</td></tr><tr><td>留存公积</td><td>35,750</td><td>44,755</td><td>37,144</td><td>39,216</td><td>40,372</td></tr><tr><td>归属母公司股东权益</td><td>142,476</td><td>148,180</td><td>154,909</td><td>162,483</td><td>161,243</td></tr><tr><td>负债和股东权益</td><td>338,463</td><td>353,391</td><td>364,219</td><td>386,927</td><td>366,537</td></tr></table>

现金流量表  

<table><tr><td>会计年度 (人民币百万)</td><td>2023</td><td>2024</td><td>2025E</td><td>2026E</td><td>2027E</td></tr><tr><td>经营活动现金</td><td>23,048</td><td>22,827</td><td>26,979</td><td>32,879</td><td>41,844</td></tr><tr><td>净利润</td><td>6,396</td><td>3,542</td><td>3,284</td><td>4,311</td><td>5,648</td></tr><tr><td>折旧摊销</td><td>18,860</td><td>23,169</td><td>25,208</td><td>26,368</td><td>19,155</td></tr><tr><td>财务费用</td><td>(519.51)</td><td>(565.07)</td><td>206.71</td><td>75.90</td><td>294.58</td></tr><tr><td>投资损失</td><td>(250.09)</td><td>(302.55)</td><td>0.00</td><td>0.00</td><td>0.00</td></tr><tr><td>营运资金变动</td><td>1,922</td><td>5,252</td><td>(3,442)</td><td>(4,570)</td><td>(3,550)</td></tr><tr><td>其他经营现金</td><td>(3,361)</td><td>(8,268)</td><td>1,722</td><td>6,694</td><td>20,296</td></tr><tr><td>投资活动现金</td><td>(41,701)</td><td>(32,480)</td><td>(55,289)</td><td>(37,310)</td><td>(37,059)</td></tr><tr><td>资本支出</td><td>(53,828)</td><td>(54,924)</td><td>(53,114)</td><td>(36,250)</td><td>(36,250)</td></tr><tr><td>长期投资</td><td>0.00</td><td>0.00</td><td>(18.33)</td><td>(95.00)</td><td>(6.11)</td></tr><tr><td>其他投资现金</td><td>12,127</td><td>22,444</td><td>(2,157)</td><td>(965.31)</td><td>(802.72)</td></tr><tr><td>筹资活动现金</td><td>15,728</td><td>11,561</td><td>11,600</td><td>12,688</td><td>(24,070)</td></tr><tr><td>短期借款</td><td>(1,122)</td><td>54,879</td><td>(54,445)</td><td>300.00</td><td>300.00</td></tr><tr><td>长期借款</td><td>12,242</td><td>(1,250)</td><td>7,745</td><td>7,250</td><td>(19,358)</td></tr><tr><td>普通股增加</td><td>0.96</td><td>0.12</td><td>0.00</td><td>0.00</td><td>0.00</td></tr><tr><td>资本公积增加</td><td>2,788</td><td>1,099</td><td>(1,662)</td><td>741.59</td><td>59.54</td></tr><tr><td>其他筹资现金</td><td>1,820</td><td>(43,166)</td><td>59,962</td><td>4,396</td><td>(5,072)</td></tr><tr><td>现金净增加额</td><td>(4,263)</td><td>1,072</td><td>(16,710)</td><td>8,257</td><td>(19,286)</td></tr></table>

资料来源：公司公告、华泰研究预测

利润表  

<table><tr><td>会计年度 (人民币百万)</td><td>2023</td><td>2024</td><td>2025E</td><td>2026E</td><td>2027E</td></tr><tr><td>营业收入</td><td>45,250</td><td>57,796</td><td>70,567</td><td>83,458</td><td>95,530</td></tr><tr><td>营业成本</td><td>(35,346)</td><td>(47,314)</td><td>(57,459)</td><td>(66,013)</td><td>(73,911)</td></tr><tr><td>营业税金及附加</td><td>(222.66)</td><td>(284.39)</td><td>(347.23)</td><td>(410.66)</td><td>(470.06)</td></tr><tr><td>营业费用</td><td>(254.06)</td><td>(290.00)</td><td>(283.52)</td><td>(293.58)</td><td>(307.38)</td></tr><tr><td>管理费用</td><td>(3,153)</td><td>(4,205)</td><td>(5,064)</td><td>(5,905)</td><td>(6,664)</td></tr><tr><td>财务费用</td><td>3,774</td><td>2,153</td><td>206.71</td><td>75.90</td><td>294.58</td></tr><tr><td>资产减值损失</td><td>(1,344)</td><td>502.34</td><td>(1,344)</td><td>(1,344)</td><td>(1,344)</td></tr><tr><td>公允价值变动收益</td><td>356.60</td><td>30.56</td><td>159.49</td><td>182.22</td><td>124.09</td></tr><tr><td>投资净收益</td><td>250.09</td><td>502.20</td><td>528.02</td><td>426.77</td><td>485.66</td></tr><tr><td>营业利润</td><td>6,906</td><td>6,299</td><td>5,200</td><td>6,365</td><td>7,564</td></tr><tr><td>营业外收入</td><td>11.72</td><td>11.26</td><td>11.29</td><td>11.42</td><td>11.33</td></tr><tr><td>营业外支出</td><td>(77.18)</td><td>(79.75)</td><td>(56.66)</td><td>(71.20)</td><td>(69.20)</td></tr><tr><td>利润总额</td><td>6,840</td><td>6,179</td><td>5,200</td><td>6,365</td><td>7,564</td></tr><tr><td>所得税</td><td>(444.27)</td><td>(942.50)</td><td>(939.38)</td><td>(939.38)</td><td>(939.38)</td></tr><tr><td>净利润</td><td>6,396</td><td>3,699</td><td>3,419</td><td>4,465</td><td>5,783</td></tr><tr><td>少数股东损益</td><td>(1,573)</td><td>(1,718)</td><td>134.66</td><td>153.70</td><td>134.66</td></tr><tr><td>归属母公司净利润</td><td>4,823</td><td>3,699</td><td>3,284</td><td>4,311</td><td>5,648</td></tr><tr><td>EBITDA</td><td>23,802</td><td>27,568</td><td>29,635</td><td>32,908</td><td>25,308</td></tr><tr><td>EPS(人民币，基本)</td><td>0.61</td><td>0.43</td><td>0.41</td><td>0.54</td><td>0.71</td></tr></table>

主要财务比率  

<table><tr><td>会计年度(%)</td><td>2023</td><td>2024</td><td>2025E</td><td>2026E</td><td>2027E</td></tr><tr><td>成长能力</td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>营业收入</td><td>(13.09)</td><td>27.02</td><td>22.10</td><td>18.27</td><td>14.46</td></tr><tr><td>营业利润</td><td>(100.53)</td><td>(900.72)</td><td>(17.44)</td><td>22.40</td><td>18.84</td></tr><tr><td>归属母公司净利润</td><td>(50.35)</td><td>(45.40)</td><td>(11.21)</td><td>31.26</td><td>31.02</td></tr><tr><td>获利能力 (%)</td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>毛利率</td><td>19.26</td><td>18.03</td><td>18.58</td><td>20.90</td><td>22.63</td></tr><tr><td>净利率</td><td>14.28</td><td>6.14</td><td>4.65</td><td>5.17</td><td>5.91</td></tr><tr><td>ROE</td><td>4.60</td><td>2.42</td><td>2.16</td><td>2.72</td><td>3.49</td></tr><tr><td>ROIC</td><td>0.02</td><td>0.01</td><td>0.01</td><td>0.02</td><td>0.01</td></tr><tr><td>偿债能力</td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>资产负债率(%)</td><td>35.45</td><td>35.17</td><td>34.79</td><td>36.38</td><td>32.91</td></tr><tr><td>净负债比率 (%)</td><td>19.56</td><td>25.25</td><td>46.79</td><td>45.33</td><td>46.98</td></tr><tr><td>流动比率</td><td>1.79</td><td>1.69</td><td>1.51</td><td>1.55</td><td>1.32</td></tr><tr><td>速动比率</td><td>1.43</td><td>1.35</td><td>1.06</td><td>1.09</td><td>0.80</td></tr><tr><td>营运能力</td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>总资产周转率</td><td>0.14</td><td>0.17</td><td>0.20</td><td>0.22</td><td>0.25</td></tr><tr><td>应收账款周转率</td><td>4.83</td><td>6.25</td><td>6.71</td><td>7.43</td><td>8.24</td></tr><tr><td>应付账款周转率</td><td>1.77</td><td>2.03</td><td>2.75</td><td>3.04</td><td>3.40</td></tr><tr><td>每股指标 (人民币)</td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>每股收益(最新摊薄)</td><td>0.60</td><td>0.46</td><td>0.41</td><td>0.54</td><td>0.71</td></tr><tr><td>每股经营现金流(最新摊薄)</td><td>3.05</td><td>2.89</td><td>3.38</td><td>4.12</td><td>5.24</td></tr><tr><td>每股净资产(最新摊薄)</td><td>18.28</td><td>18.73</td><td>19.42</td><td>20.37</td><td>20.21</td></tr><tr><td>估值比率</td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>PE(倍)</td><td>163.90</td><td>213.72</td><td>240.69</td><td>183.37</td><td>139.95</td></tr><tr><td>PB(倍)</td><td>5.42</td><td>5.29</td><td>5.10</td><td>4.87</td><td>4.90</td></tr><tr><td>EV EBITDA(倍)</td><td>24.64</td><td>22.23</td><td>20.83</td><td>18.97</td><td>24.67</td></tr></table>

# 免责声明

# 分析师声明

本人，黄乐平、谢春生、陈旭东，兹证明本报告所表达的观点准确地反映了分析师对标的证券或发行人的个人意见；  
彼以往、现在或未来并无就其研究报告所提供的具体建议或所表达的意见直接或间接收取任何报酬。

# 一般声明及披露

本报告由华泰证券股份有限公司（已具备中国证监会批准的证券投资咨询业务资格，以下简称“本公司"）制作。本报告所载资料是仅供接收人的严格保密资料。本报告仅供本公司及其客户和其关联机构使用。本公司不因接收人收到本报告而视其为客户。

本报告基于本公司认为可靠的、已公开的信息编制，但本公司及其关联机构(以下统称为“华泰”)对该等信息的准确性及完整性不作任何保证。

本报告所载的意见、评估及预测仅反映报告发布当日的观点和判断。在不同时期，华泰可能会发出与本报告所载意见、评估及预测不一致的研究报告。同时，本报告所指的证券或投资标的的价格、价值及投资收入可能会波动。以往表现并不能指引未来，未来回报并不能得到保证，并存在损失本金的可能。华泰不保证本报告所含信息保持在最新状态。华泰对本报告所含信息可在不发出通知的情形下做出修改，投资者应当自行关注相应的更新或修改。

本公司不是FINRA的注册会员，其研究分析师亦没有注册为 FINRA 的研究分析师/不具有 FINRA 分析师的注册资格。

华泰力求报告内容客观、公正，但本报告所载的观点、结论和建议仅供参考，不构成购买或出售所述证券的要约或招揽。该等观点、建议并未考虑到个别投资者的具体投资目的、财务状况以及特定需求，在任何时候均不构成对客户私人投资建议。投资者应当充分考虑自身特定状况，并完整理解和使用本报告内容，不应视本报告为做出投资决策的唯一因素。对依据或者使用本报告所造成的一切后果，华泰及作者均不承担任何法律责任。任何形式的分享证券投资收益或者分担证券投资损失的书面或口头承诺均为无效。

除非另行说明，本报告中所引用的关于业绩的数据代表过往表现，过往的业绩表现不应作为日后回报的预示。华泰不承诺也不保证任何预示的回报会得以实现，分析中所做的预测可能是基于相应的假设，任何假设的变化可能会显著影响所预测的回报。

华泰及作者在自身所知情的范围内，与本报告所指的证券或投资标的不存在法律禁止的利害关系。在法律许可的情况下，华泰可能会持有报告中提到的公司所发行的证券头寸并进行交易，为该公司提供投资银行、财务顾问或者金融产品等相关服务或向该公司招揽业务。

华泰的销售人员、交易人员或其他专业人士可能会依据不同假设和标准、采用不同的分析方法而口头或书面发表与本报告意见及建议不一致的市场评论和/或交易观点。华泰没有将此意见及建议向报告所有接收者进行更新的义务。华泰的资产管理部门、自营部门以及其他投资业务部门可能独立做出与本报告中的意见或建议不一致的投资决策。投资者应当考虑到华泰及/或其相关人员可能存在影响本报告观点客观性的潜在利益冲突。投资者请勿将本报告视为投资或其他决定的唯一信赖依据。有关该方面的具体披露请参照本报告尾部。

本报告并非意图发送、发布给在当地法律或监管规则下不允许向其发送、发布的机构或人员，也并非意图发送、发布给因可得到、使用本报告的行为而使华泰违反或受制于当地法律或监管规则的机构或人员。

本报告版权仅为本公司所有。未经本公司书面许可，任何机构或个人不得以翻版、复制、发表、引用或再次分发他人(无论整份或部分)等任何形式侵犯本公司版权。如征得本公司同意进行引用、刊发的，需在允许的范围内使用，并需在使用前获取独立的法律意见，以确定该引用、刊发符合当地适用法规的要求，同时注明出处为“华泰证券研究所”，且不得对本报告进行任何有悼原意的引用、删节和修改。本公司保留追究相关责任的权利。所有本报告中使用的商标、服务标记及标记均为本公司的商标、服务标记及标记。

# 中国香港

本报告由华泰证券股份有限公司制作，在香港由华泰金融控股（香港）有限公司向符合《证券及期货条例》及其附属法律规定的机构投资者和专业投资者的客户进行分发。华泰金融控股（香港）有限公司受香港证券及期货事务监察委员会监管，是华泰国际金融控股有限公司的全资子公司，后者为华泰证券股份有限公司的全资子公司。在香港获得本报告的人员若有任何有关本报告的问题,请与华泰金融控股（香港）有限公司联系。

# 香港-重要监管披露

·华泰金融控股（香港）有限公司的雇员或其关联人士没有担任本报告中提及的公司或发行人的高级人员。  
·中芯国际（688981CH)、中芯国际（981HK)：华泰金融控股（香港）有限公司、其子公司和/或其关联公司在本报告发布日担任标的公司证券做市商或者证券流动性提供者。  
·有关重要的披露信息，请参华泰金融控股（香港）有限公司的网页 htps://www.htsc.com.hk/stock_disclosure  
其他信息请参见下方“美国-重要监管披露”。

# 美国

在美国本报告由华泰证券（美国）有限公司向符合美国监管规定的机构投资者进行发表与分发。华泰证券（美国）有限公司是美国注册经纪商和美国金融业监管局（FINRA）的注册会员。对于其在美国分发的研究报告，华泰证券（美国）有限公司根据《1934年证券交易法》（修订版）第15a-6条规定以及美国证券交易委员会人员解释，对本研究报告内容负责。华泰证券（美国）有限公司联营公司的分析师不具有美国金融监管（FINRA）分析师的注册资格，可能不属于华泰证券（美国）有限公司的关联人员，因此可能不受FINRA关于分析师与标的公司沟通、公开露面和所持交易证券的限制。华泰证券（美国）有限公司是华泰国际金融控股有限公司的全资子公司，后者为华泰证券股份有限公司的全资子公司。任何直接从华泰证券（美国）有限公司收到此报告并希望就本报告所述任何证券进行交易的人士，应通过华泰证券（美国）有限公司进行交易。

# 美国-重要监管披露

·分析师黄乐平、谢春生、陈旭东本人及相关人士并不担任本报告所提及的标的证券或发行人的高级人员、董事或顾问。分析师及相关人士与本报告所提及的标的证券或发行人并无任何相关财务利益。本披露中所提及的“相关人士”包括 FINRA 定义下分析师的家庭成员。分析师根据华泰证券的整体收入和盈利能力获得薪酬，包括源自公司投资银行业务的收入。中芯国际（688981CH)、中芯国际（981HK)：华泰证券股份有限公司、其子公司和/或其联营公司在本报告发布日担任标的公司证券做市商或者证券流动性提供者。华泰证券股份有限公司、其子公司和/或其联营公司，及/或不时会以自身或代理形式向客户出售及购买华泰证券研究所覆盖公司的证券/衍生工具，包括股票及债券（包括衍生品）华泰证券研究所覆盖公司的证券/衍生工具，包括股票及债券(包括衍生品)。华泰证券股份有限公司、其子公司和/或其联营公司，及/或其高级管理层、董事和雇员可能会持有本报告中所提到的任何证券（或任何相关投资）头寸，并可能不时进行增持或减持该证券（或投资)。因此，投资者应该意识到可能存在利益冲突。本报告所载的观点、结论和建议仅供参考，不构成购买或出售所述证券的要约或招揽，亦不试图促进购买或销售该等证券。如任何投资者为美国公民、取得美国永久居留权的外国人、根据美国法律所设立的实体（包括外国实体在美国的分支机构)、任何位于美国的个人，该等投资者应当充分考虑自身特定状况，不以任何形式直接或间接地投资本报告涉及的投资者所在国相关适用的法律法规所限制的企业的公开交易的证券、其衍生证券及用于为该等证券提供投资机会的证券的任何交易。该等投资者对依据或者使用本报告内容所造成的一切后果，华泰证券股份有限公司、华泰金融控股（香港）有限公司、华泰证券（美国）有限公司及作者均不承担任何法律责任。

# 新加坡

华泰证券（新加坡）有限公司持有新加坡金融管理局颁发的资本市场服务许可证，可从事资本市场产品交易，包括证券、集体投资计划中的单位、交易所交易的衍生品合约和场外衍生品合约，并且是《财务顾问法》规定的豁免财务顾问，就投资产品向他人提供建议，包括发布或公布研究分析或研究报告。华泰证券（新加坡）有限公司可能会根据《财务顾问条例》第32C条的规定分发其在华泰内的外国附属公司各自制作的信息/研究。本报告仅供认可投资者、专家投资者或机构投资者使用，华泰证券（新加坡）有限公司不对本报告内容承担法律责任。如果您是非预期接收者，请您立即通知并直接将本报告返回给华泰证券（新加坡）有限公司。本报告的新加坡接收者应联系您的华泰证券（新加坡）有限公司关系经理或客户主管，了解来自或与所分发的信息相关的事宜。

# 评级说明

投资评级基于分析师对报告发布日后6至12个月内行业或公司回报潜力（含此期间的股息回报）相对基准表现的预期(A股市场基准为沪深300指数，香港市场基准为恒生指数，美国市场基准为标普500指数，台湾市场基准为台湾加权指数，日本市场基准为日经225指数，新加坡市场基准为海峡时报指数，韩国市场基准为韩国有价证券指数，英国市场基准为富时100 指数)，具体如下：

# 行业评级

增持：预计行业股票指数超越基准 中性：预计行业股票指数基本与基准持平 减持：预计行业股票指数明显弱于基准

# 公司评级

买入：预计股价超越基准15%以上增持：预计股价超越基准5%\~15%持有：预计股价相对基准波动在-15%\~5%之间卖出：预计股价弱于基准15%以上

暂停评级：已暂停评级、目标价及预测，以遵守适用法规及/或公司政策无评级：股票不在常规研究覆盖范围内。投资者不应期待华泰提供该等证券及/或公司相关的持续或补充信息

# 法律实体披露

中国：华泰证券股份有限公司具有中国证监会核准的“证券投资咨询”业务资格，经营许可证编号为：91320000704041011J香港：华泰金融控股(香港)有限公司具有香港证监会核准的“就证券提供意见”业务资格，经营许可证编号为：AOK809美国：华泰证券（美国）有限公司为美国金融业监管局（FINRA）成员，具有在美国开展经纪交易商业务的资格，经营业务许可编号为：CRD#:298809/SEC#:8-70231

i加坡：华泰证券（新加坡）有限公司具有新加坡金融管理局颁发的资本市场服务许可证，并且是豁免财务顾问。公司注册号：202233398E

# 华泰证券股份有限公司

南京南京市建邮区江东中路228号华泰证券广场1号楼/邮政编码：210019电话：86 25 83389999/传真：8625 83387521电子邮件：ht-rd@htsc.com

北京  
北京市西城区太平桥大街丰盛胡同28号太平洋保险大厦A座18层/  
邮政编码：100032  
电话：86 10 63211166/传真：86 10 63211275  
电子邮件：ht-rd@htsc.com  
深圳  
深圳市福田区益田路5999号基金大厦10楼/邮政编码：518017  
电话：86 755 82493932/传真：86 755 82492062  
电子邮件：ht-rd@htsc.com  
上海  
上海市浦东新区东方路18号保利广场E栋23楼/邮政编码：200120  
电话：862128972098/传真：862128972068  
电子邮件：ht-rd@htsc.com  
华泰金融控股（香港）有限公司  
香港中环皇后大道中99号中环中心53楼  
电话：+852-3658-6000/传真：+852-2567-6123  
电子邮件：research@htsc.com  
http://www.htsc.com.hk  
华泰证券（美国）有限公司  
美国纽约公园大道280号21楼东(纽约10017)  
电话：+212-763-8160/传真：+917-725-9702  
电子邮件: Huatai@htsc-us.com  
http://www.htsc-us.com  
华泰证券（新加坡）有限公司  
滨海湾金融中心1号大厦，#08-02，新加坡018981  
电话：+65 68603600  
传真：+65 65091183

③版权所有2025年华泰证券股份有限公司