公司评级 增持（维持）

报告日期 2025年05月12日

<table><tr><td colspan="2">基础数据</td></tr><tr><td>05月09日收盘价（港 元）</td><td>43.00</td></tr><tr><td>总市值 (亿港元)</td><td>3,433.88</td></tr><tr><td>总股本(亿股)</td><td>79.86</td></tr></table>

来源：聚源，兴业证券经济与金融研究院整理

# 相关研究

【兴证海外TMT】中芯国际24Q4点评：24Q4毛利率超指引,25H1补库需求顺风-2025.02.20  
【兴证海外TMT】中芯国际24Q3跟踪：12 英寸业务稳增长，季度收入首超20亿美元-2024.11.13  
分析师：洪嘉骏  
S0190519080002  
BPL829  
hongjiajun@xyzq.com.cn

研究助理：许峰泷xufenglong@xyzq.com.cn

# 中芯国际(00981.HK)

# 季度盈利低于预期，看好国产芯片长期空间

# 投资要点：

·25Q1：生产事件突发导致单价下滑。中芯国际2025Q1收入22.47亿美元（YoY+28.4%，QoQ+1.8%），略低于Factset一致预期的 23.59 亿美元，毛利率 22.5%（YoY+8.8pcts,QoQ-0.1pct），高于指引为19%-21%，归母净利润1.88 亿美元（YoY+161.9%，QoQ+74.8%），低于Factset一致预期为2.26亿美元。2025Q2收入指引区间环比下降4%至6%，中值对应为21.35亿美元，低于市场一致预期的24.53亿美元，结构上公司预计出货量稳定，ASP下滑，毛利率指引区间18%-20%。

·工业、汽车收入环比高增，2025年手机、PC、平板电脑存在调整压力。中芯国际2025Q1工业、汽车收入2.05亿美元（YoY+75%，QoQ+23%），环比高增，公司积极布局汽车电子平台战略取得成效，公司作为国产汽车电子厂商的重要合作伙伴，有望受益于国产汽车产业成长趋势。消费类方面，管理层预估8、9月份手机可能出现典型的需求修正，电脑销售表现平稳，但缺乏库存、订单大幅增长的催化因素，平板需求平稳，但供给增长导致了价格压力。虽然当前市场可见度较低，但我们仍然看好公司在国产替代、LocalforLocal趋势中的发展机遇。

·2025资本开支计划维持，生产事件影响预计延续到Q3。产能方面，中芯国际2025年Q1月产能为97.3万片（YoY+19%，QoQ+3%），公司预计全年资本开支同比持平，维持原本的计划。出货量方面，中芯国际2025年Q1季度出货量229.2万片（YoY+27.7%，QoQ+15.1%），季度内，公司因年度维修和设备验证等生产事件导致良率波动，生产事件虽未影响公司晶圆出货量，但公司与客户下调了晶圆价格作为协商结果，管理层预计影响将延续到Q3。

·投资建议：受生产事件影响，我们下修公司2025年的收入、盈利预测，但我们仍长期看好公司在半导体制造国产替代趋势中的独特地位，并预期公司从国产先进制程芯片需求、Local forLocal进程中受益。预计公司2025-2027年收入分别为92.04/115.18/128.80 亿美元，归母净利润分别为4.47/6.50/8.32亿美元，维持“增持”评级。

·风险提示：1）生产问题解决进度不及预期风险；2）竞争加剧导致利用率、平均价格下滑风险；3）地缘政治风险

主要财务指标  

<table><tr><td>会计年度</td><td>2024</td><td>2025E</td><td>2026E</td><td>2027E</td></tr><tr><td>营业总收入 (百万美元)</td><td>8,030</td><td>9,204</td><td>11,518</td><td>12,880</td></tr><tr><td>同比增长</td><td>27.0%</td><td>14.6%</td><td>25.1%</td><td>11.8%</td></tr><tr><td>归母净利润 (百万美元)</td><td>493</td><td>447</td><td>650</td><td>832</td></tr><tr><td>同比增长</td><td>-45.4%</td><td>-9.4%</td><td>45.4%</td><td>28.0%</td></tr><tr><td>毛利率</td><td>18.03%</td><td>19.24%</td><td>20.52%</td><td>21.52%</td></tr><tr><td>每股收益 (美元)</td><td>0.06</td><td>0.06</td><td>0.08</td><td>0.10</td></tr><tr><td>市盈率</td><td>68.1</td><td>98.8</td><td>68.0</td><td>53.1</td></tr></table>

数据来源：wind，兴业证券经济与金融研究院整理注：每股收益均按照最新股本摊薄计算

附表资产负债表  
单位：百万美元  

<table><tr><td>会计年度</td><td>2024</td><td>2025E</td><td>2026E</td><td>2027E</td></tr><tr><td>流动资产</td><td>14,784</td><td>14,091</td><td>14,659</td><td>15,954</td></tr><tr><td>货币资金</td><td>6,364</td><td>5,506</td><td>5,188</td><td>5,837</td></tr><tr><td>应收账款</td><td>840</td><td>1,023</td><td>960</td><td>1,073</td></tr><tr><td>存货</td><td>2,958</td><td>3,097</td><td>3,814</td><td>4,211</td></tr><tr><td>其他</td><td>4,621</td><td>4,466</td><td>4,697</td><td>4,833</td></tr><tr><td>非流动资产</td><td>34,378</td><td>37,919</td><td>40,450</td><td>42,464</td></tr><tr><td>固定资产</td><td>28,092</td><td>31,631</td><td>34,209</td><td>36,263</td></tr><tr><td>无形资产与使用权资产</td><td>457</td><td>458</td><td>413</td><td>371</td></tr><tr><td>其他</td><td>5,829</td><td>5,829</td><td>5,829</td><td>5,829</td></tr><tr><td>资产总计</td><td>49,161</td><td>52,010</td><td>55,110</td><td>58,418</td></tr><tr><td>流动负债</td><td>8,760</td><td>8,843</td><td>9,449</td><td>10,022</td></tr><tr><td>短期借款</td><td>2,926</td><td>2,926</td><td>2,926</td><td>2,926</td></tr><tr><td>应付账款</td><td>3,729</td><td>3,717</td><td>4,069</td><td>4,492</td></tr><tr><td>其他</td><td>2,104</td><td>2,199</td><td>2,454</td><td>2,604</td></tr><tr><td>非流动负债</td><td>8,532</td><td>10,532</td><td>12,032</td><td>13,532</td></tr><tr><td>长期借款</td><td>8,038</td><td>10,038</td><td>11,538</td><td>13,038</td></tr><tr><td>其他</td><td>494</td><td>494</td><td>494</td><td>494</td></tr><tr><td>负债合计</td><td>17,292</td><td>19,374</td><td>21,481</td><td>23,554</td></tr><tr><td>普通股股本</td><td>32</td><td>32</td><td>32</td><td>32</td></tr><tr><td>储备</td><td>20,582</td><td>20,912</td><td>21,446</td><td>22,161</td></tr><tr><td>归属母公司股东权益</td><td>20,614</td><td>20,944</td><td>21,478</td><td>22,193</td></tr><tr><td>少数股东权益</td><td>11,256</td><td>11,691</td><td>12,151</td><td>12,671</td></tr><tr><td>股东权益合计</td><td>31,870</td><td>32,636</td><td>33,629</td><td>34,864</td></tr><tr><td>负债和股东权益</td><td>49,161</td><td>52,010</td><td>55,110</td><td>58,418</td></tr></table>

利润表 单位：百万美元  

<table><tr><td>会计年度</td><td>2024</td><td>2025E</td><td>2026E</td><td>2027E</td></tr><tr><td>营业收入</td><td>8,030</td><td>9,204</td><td>11,518</td><td>12,880</td></tr><tr><td>营业成本</td><td>6,582</td><td>7,434</td><td>9,154</td><td>10,107</td></tr><tr><td>毛利</td><td>1,448</td><td>1,771</td><td>2,364</td><td>2,772</td></tr><tr><td>研发支出</td><td>765</td><td>831</td><td>1,029</td><td>1,027</td></tr><tr><td>销售费用</td><td>40</td><td>47</td><td>61</td><td>66</td></tr><tr><td>管理费用</td><td>580</td><td>676</td><td>738</td><td>807</td></tr><tr><td>税前利润</td><td>860</td><td>1,038</td><td>1,305</td><td>1,590</td></tr><tr><td>所得税</td><td>130</td><td>156</td><td>196</td><td>239</td></tr><tr><td>净利润</td><td>730</td><td>882</td><td>1,110</td><td>1,352</td></tr><tr><td>少数股东损益</td><td>237</td><td>435</td><td>460</td><td>520</td></tr><tr><td>归属母公司净利润</td><td>493</td><td>447</td><td>650</td><td>832</td></tr><tr><td>EPS(美元)</td><td>0.06</td><td>0.06</td><td>0.08</td><td>0.10</td></tr></table>

主要财务比率  

<table><tr><td>会计年度</td><td>2024</td><td>2025E</td><td>2026E</td><td>2027E</td></tr><tr><td>成长性</td><td></td><td></td><td></td><td></td></tr><tr><td>营业收入增长率</td><td>27.0%</td><td>14.6%</td><td>25.1%</td><td>11.8%</td></tr><tr><td>归母净利润增长率</td><td>-45.4%</td><td>-9.4%</td><td>45.4%</td><td>28.0%</td></tr><tr><td>盈利能力</td><td></td><td></td><td></td><td></td></tr><tr><td>毛利率</td><td>18.03%</td><td>19.24%</td><td>20.52%</td><td>21.52%</td></tr><tr><td>归母净利率</td><td>6.14%</td><td>4.85%</td><td>5.64%</td><td>6.46%</td></tr><tr><td>ROE</td><td>2.39%</td><td>2.13%</td><td>3.02%</td><td>3.75%</td></tr><tr><td>偿债能力</td><td></td><td></td><td></td><td></td></tr><tr><td>资产负债率</td><td>35.17%</td><td>37.25%</td><td>38.98%</td><td>40.32%</td></tr><tr><td>流动比率</td><td>1.69</td><td>1.59</td><td>1.55</td><td>1.59</td></tr><tr><td>速动比率</td><td>1.35</td><td>1.24</td><td>1.15</td><td>1.17</td></tr><tr><td>营运能力</td><td></td><td></td><td></td><td></td></tr><tr><td>资产周转率</td><td>0.17</td><td>0.18</td><td>0.22</td><td>0.23</td></tr><tr><td>每股资料 (美元）</td><td></td><td></td><td></td><td></td></tr><tr><td>每股收益</td><td>0.06</td><td>0.06</td><td>0.08</td><td>0.10</td></tr><tr><td>每股经营现金</td><td>0.40</td><td>0.50</td><td>0.72</td><td>0.84</td></tr><tr><td>估值比率 (倍)</td><td></td><td></td><td></td><td></td></tr><tr><td>PE</td><td>68.1</td><td>98.8</td><td>68.0</td><td>53.1</td></tr><tr><td>PB</td><td>1.6</td><td>2.1</td><td>2.1</td><td>2.0</td></tr></table>

现金流量表  

<table><tr><td>会计年度</td><td>2024</td><td>2025E</td><td>2026E</td><td>2027E</td></tr><tr><td>净利润</td><td>730</td><td>882</td><td>1,110</td><td>1,352</td></tr><tr><td>折旧和摊销</td><td>3,223</td><td>3,809</td><td>4,468</td><td>4,986</td></tr><tr><td>经营活动现金流量</td><td>3,176</td><td>3,967</td><td>5,710</td><td>6,721</td></tr><tr><td>投资活动现金流量</td><td>-4,518</td><td>-6,350</td><td>-7,000</td><td>-7,000</td></tr><tr><td>融资活动现金流量</td><td>1,608</td><td>1,641</td><td>1,089</td><td>1,044</td></tr><tr><td>现金净变动</td><td>149</td><td>-859</td><td>-318</td><td>648</td></tr><tr><td>现金的期初余额</td><td>6,215</td><td>6,364</td><td>5,506</td><td>5,188</td></tr><tr><td>现金的期末余额</td><td>6,364</td><td>5,506</td><td>5,188</td><td>5,837</td></tr></table>

单位：百万美元  
数据来源：wind、兴业证券经济与金融研究院注：每股收益均按照最新股本摊薄计算

# 分析师声明

本人具有中国证券业协会授予的证券投资咨询执业资格并登记为证券分析师，以勤勉的职业态度，独立、客观地出具本报告。本报告清晰准确地反映了本人的研究观点。本人不曾因，不因，也将不会因本报告中的具体推荐意见或观点而直接或间接收到任何形式的补偿。

投资评级说明  

<table><tr><td rowspan=1 colspan=1>投资建议的评级标准</td><td rowspan=1 colspan=1>类别</td><td rowspan=1 colspan=1>评级</td><td rowspan=1 colspan=1>说明</td></tr><tr><td rowspan=8 colspan=1>报告中投资建议所涉及的评级分为股票评级和行业评级（另有说明的除外）。评级标准为报告发布日后的12个月内公司股价（或行业指数）相对同期相关证券市场代表性指数的涨跌幅。其中：沪深两市以沪深300 指数为基准；北交所市场以北证50指数为基准；新三板市场以三板成指为基准；香港市场以恒生指数为基准；美国市场以标普500或纳斯达克综合指数为基准。</td><td rowspan=5 colspan=1>股票评级</td><td rowspan=1 colspan=1>买入</td><td rowspan=1 colspan=1>相对同期相关证券市场代表性指数涨幅大于15%</td></tr><tr><td rowspan=1 colspan=1>增持</td><td rowspan=1 colspan=1>相对同期相关证券市场代表性指数涨幅在5%～15%之间</td></tr><tr><td rowspan=1 colspan=1>中性</td><td rowspan=1 colspan=1>相对同期相关证券市场代表性指数涨幅在-5%～5%之间</td></tr><tr><td rowspan=1 colspan=1>减持</td><td rowspan=1 colspan=1>相对同期相关证券市场代表性指数涨幅小于-5%</td></tr><tr><td rowspan=1 colspan=1>无评级</td><td rowspan=1 colspan=1>由于我们无法获取必要的资料，或者公司面临无法预见结果的重大不确定性事件，或者其他原因，致使我们无法给出明确的投资评级</td></tr><tr><td rowspan=3 colspan=1>行业评级</td><td rowspan=1 colspan=1>推荐</td><td rowspan=1 colspan=1>相对表现优于同期相关证券市场代表性指数</td></tr><tr><td rowspan=1 colspan=1>中性</td><td rowspan=1 colspan=1>相对表现与同期相关证券市场代表性指数持平</td></tr><tr><td rowspan=1 colspan=1>回避</td><td rowspan=1 colspan=1>相对表现弱于同期相关证券市场代表性指数</td></tr></table>

# 信息披露

本公司在知晓的范围内履行信息披露义务。客户可登录wwW.xyzq.com.cn 内幕交易防控栏内查询静默期安排和关联公司持股情况。

本公司为中芯国际(688981)做市商。但上述持仓不曾、不会、不将对研究业务的独立性、客观性产生影响。

# 有关财务权益及商务关系的披露

兴证国际证券有限公司及/或其有关联公司在过去十二个月内与福建漳龙集团有限公司、焦作市国有资本运营（控股）集团有限公司、临沂城市发展国际有限公司、临沂城市发展集团有限公司、山东黄金集团有限公司、双城(重庆)信用增进股份有限公司、成都天府大港集团有限公司、成都经开产业投资集团有限公司、中国长城资产（国际）控股有限公司、知识城（广州）投资集团有限公司、重庆三峡融资担保集团股份有限公司、成都兴锦建设投资集团有限责任公司、贵溪经开控股发展集团有限公司、江西省信用融资担保集团股份有限公司、湖州吴兴人才产业投资发展集团有限公司、江苏正力新能电池技术股份有限公司、信华达投资发展有限公司、漳州市交通发展集团有限公司、重庆兴农融资担保集团有限公司、凉山州发展(控股)集团有限责任公司、滕州信华投资集团有限公司、三水国际发展有限公司、湖州吴兴国有资本投资发展有限公司、金峰有限公司、越秀房产信托基金、越秀房托资产管理有限公司、福建省晋尚控股集团有限公司、唐山控股发展集团股份有限公司、唐山国际投资(香港)有限公司、淮安开发控股有限公司、佛山市高明建设投资集团有限公司、保定国家高新技术产业开发区发展有限公司、都江堰市城乡建设集团有限公司、河南航空港投资集团有限公司、河南省中豫融资担保有限公司、泉州市南翼投资集团有限公司、济源济康科技有限公司、兰溪市国有资本运营有限公司、兰溪市交通建设投资集团有限公司、青岛市即墨区城市开发投资有限公司、株洲市城市建设发展集团有限公司、福建石狮国有资本运营集团有限责任公司、福建红树林投资集团有限公司、漳州市龙海区国有资产投资经营有限公司、浙江长兴金融控股集团有限公司、滨江国投有限公司、泰州港城投资集团有限公司、扬州经济技术开发区开发(集团)有限公司、淄博市城市资产运营集团有限公司、青岛北岸控股集团有限责任公司、青岛动车小镇投资集团有限公司、青岛胶州城市发展投资有限公司、滕州信华投资集团有限公司、青岛蓝谷投资发展集团有限公司、重庆市合川城市建设投资(集团)有限公司、晋江市路桥建设开发有限公司、福建省晋江市建设投资控股集团有限公司、北京银行、湘潭振湘国有资产经营投资有限公司、湖北省联合发展投资集团有限公司、江西省信用融资担保集团股份有限公司、萍乡市城市建设投资集团有限公司、岳阳市城市建设投资集团有限公司、沂盛（维尔京）国际有限公司、山东沂蒙产业集团有限公司、嵊州市城市建设投资发展集团有限公司、江苏姜堰经开集团有限公司、丽水经济技术开发区实业发展集团有限公司、印象大红袍股份有限公司、兖矿集团（开曼群岛）有限公司、山东能源集团有限公司、南阳城投控股有限公司、科学城(广州)融资租赁有限公司、科学城(广州）投资集团有限公司、淮安市投资控股集团有限公司、淮北市建设投资有限责任公司、稠州国际投资有限公司、江门高新技术工业园有限公司、义乌市国有资本运营有限公司、安徽海螺材料科技股份有限公司、安徽海螺水泥股份有限公司、脑动极光医疗科技有限公司、四川省金玉融资担保有限公司、天长市农业发展有限公司、徽商银行股份有限公司、湖北省融资担保集团有限责任公司、抚州市数字经济投资集团有限公司、重庆兴农融资担保集团有限公司、重庆三峡融资担保集团股份有限公司、重庆丰都文化旅游集团有限公司、盐城高新区投资集团有限公司、浙江德盛（BVI）有限公司、杭州富阳交通发展投资集团有限公司、成都市羊安新城开发建设有限公司、三水国际发展有限公司、江苏姜堰经开集团有限公司、唐山国控集团有限公司、曹妃甸国控投资集团有限公司、贵溪市发展投资集团有限公司、青岛市即墨区城市旅游开发投资有限公司、怀远县新型城镇化建设有限公司、湖州市城市投资发展集团有限公司、安徽西湖投资控股集团有限公司、淮北市建投控股集团有限公司、衢州市衢通发展集团有限公司、山东泉汇产业发展有限公司、成都武侯产业发展投资管理集团有限公司、宁国市宁阳控股集团有限公司、温州市鹿城区国有控股集团有限公司、邹城市城资控股集团有限公司、山东明水国开发展集团有限公司、河南中豫信用增进有限公司、南阳交通控股集团有限公司、中原大禹国际（BVI）有限公司、中原资产管理有限公司、宜昌高新投资开发有限公司、威海市环通产业投资集团有限公司、成都交通投资集团有限公司、滨州市滨城区经济开发投资有限公司、福清市国有资产营运投资集团有限公司、湖州莫干山高新集团有限公司、湖州莫干山国有资本控股集团有限公司、漳州高鑫发展有限公司、郑州地铁集团有限公司、漳州圆山发展有限公司、靖江港口集团有限公司、娄底市城市发展控股集团有限公司、怀远县新型城镇化建设有限公司、徽商银行、烟台国丰投资控股集团有限公司、济南高新控股集团有限公司、洛阳国晟投资控股集团有限公司、漳州台商投资区资产运营集团有限公司、浙江省新昌县投资发展集团有限公司、浦江县国有资本投资集团有限公司、万晟国际（维尔京）有限公司、平度市城市开发集团有限公司、XD民生银行、新沂市交通文旅集团有限公司、常德财鑫融资担保有限公司、湖南瑞鑫产业运营管理有限公司、赣州城市投资控股集团有限责任公司、湖北省融资担保集团有限责任公司、黄石产投控股集团有限公司、赤壁城市发展集团有限公司、江苏中扬清洁能源发展有限公司、重庆三峡融资担保集团股份有限公司、江苏银行、无锡恒廷实业有限公司、四海国际投资有限公司、福建省晋江市建设投资控股集团有限公司、济南章丘控股集团有限公司、湖南省汨罗江控股集团有限公司、湖南省融资担保集团有限公司、中国信达(香港)控股有限公司、重庆兴农融资担保集团有限公司、资阳发展投资集团有限公司、荆州市城市发展控股集团有限公司、南京银行、淄博市城市资产运营集团有限公司、宜宾市新兴产业投资集团有限公司、上饶创新发展产业投资集团有限公司、中原豫资投资控股集团有限公司、九江银行、南昌金开集团有限公司、无锡市交通产业集团有限公司、保定市国控集团有限责任公司、海翼（香港）有限公司、济南市中财金投资集团有限公司、政金金融国际(BVI)有限公司、重庆新双圈城市建设开发有限公司、山东高速集团、青岛军民融合发展集团有限公司、泰兴市港口集团有限公司、FujianZhanglongGroupCo.,Ltd.、Jiaozuo State-ownedCapitalOperation(Holding）GroupCo.，Ltd.、LinyiCityDevelopmentInternationalCo.Limited、LINYICITYDEVELOPMENTGROUPCO.,LTDShandongGoldGroupCo.,Ltd.、Chengdu-ChongqingBondsuranceCo,Ltd.、SDGFinanceLimited、ChengduTianfuDagangGoupCo,Ltd.、ChengduEconomicDvelopmentIdustialInvestmentGroupCo,Ltd、ChinaGratWallIternational HdingsVLimited、ChinaGratWallAMC(nternational)HldingsCompanyLimited、KnowledgeCity(Guangzhou)IvestmentGroupCo,Ltd.ChongqingSanXiaFinancingGuaranteeGroupCo.,Ld、ChengduXingjinConstructionIestment

GroupCo.,Ltd.GuiiJingkaiHoldingDevelopmentGroupCo.Ltd.、HuzhouWuxingIdustrialnvestmentDevelopmentGroupCod.、Wu xingIndustryInvestment Husheng CompanyLimited、JiangsuZenergyBateryTechnologiesGroupCo.Ltd.、ZhangzhouTransportation DevelopmentGroupCo,d.、ChongqingXingnongFinancingGuaranteeGroupCod、LiangshanDevelopment(Holdings)GroupCotd、 TENGZHOU XINHUA INVESTMENTGROUP CO.，LTD.、SANSHUI INTERNATIONAL DEVELOPMENT CO.，LTD、HuZhou Wuxing State-OwedCapitalvestmentDevelopmentCo.,Ltd.、MoonKingLimited、YUEXIUREIT、YuexiuREITAsetManagementLimited、FUJIAN JINSHANG HOLDING GROUPCO.,LTD.（FUJIAN JINSHANG HOLDING GROUP)、Tangshan Holding Development Group Co.,LTD、 TangshanInternationalInvestment(HongKong)Co.,Ltd、HuaianDevelopmentHoldingsCoLtd、XIANGYUINVESTMEN(BV)O.D、 FOSHANGAOMINGCONSTRUCTIONINVESTMENTGROUPCO.,LTD.、Baoding National Hitech Industry Development ZoneDevelopment CoLtd、Dujangyan UrbanandRuralConstructionGroupCoLtd.、HenanAirportIvestmentGroupCoLtd、HenanZhongyuFinancing GuaranteeCo.LTD、QUANZHOUNANYIINVESTMENTGROUPCO.,LD.、JiyuanityJikang technologyCo.,LTD、LanxiState-ownedCapital Operation Co.,Ltd、LANXITRANSPORTATIONCONSTRUCTIONINVESTMENTGROUPCO.,LTD、QingdaoJimoDistictUrban Development Investment Co.,Ltd.、ZHUZHOU CITYCONSTRUCTION DEVELOPMENTGROUPCO.,LTD.、FUJIANSHISHI STATE-OWNED CAPITAL OPERATION GROUP CO.,LTD.、FUJIAN MANGROVEINVESTMENT GROUP CO.,LTD.、ZHANGZHOULONGHAI STATE-OWNED ASSETS INVESTMENT AND OPERATION CO.,LTD.、ZHEJIANG CHANGXING FINANCIAL HOLDINGS GROUP CO.,LTD.、BINJIANG GUOTOU LIMITED、TAIZHOU GANGCHENG INVESTMENT GROUPCO.LTD.、Yangzhou Economic Development Zone Co.,Ltd.、ZiboCity Asset OperationGroupCo.,Ltd.、QingdaoNorthShoreHolding GroupCo.,Ltd.、QINGDAOBULLETTRAINTOWNINVESTMENTGROUPCOD、 QINGDAO JIAOZHOU URBAN DEVELOPMENT AND INVESTMENT CO.，LTD.、CHONGQING HECHUAN CITY CONSTRUCTION INVESTMENT(GROUP)CO.,LTD.、BANK OF BEIJING、XIANGTAN ZHENXIANG STATE-OWNED ASSETS MANAGEMENT INVESTMENT CO,LTD.、HUBEIUNITEDDEVELOPMENTINVESTMENTGROUPCO.,LTD.ShengzhouUrbanConstructionnvestmentDevelopmentGroup Co.,Ltd.、LISHUIECONOMICAND TECHNOLOGICALDEVELOPMENTZONE INDUSTRIALDEVELOPMENTGROUPCO.,LTD.、Impression Dahongpao Co.,Ltd.、NANYANGURBAN INVESTMENT HOLDINGS CO.,LTD.、SCIENCE CITY(GUANGZHOU)FINANCIALLEASING CO, LTD.、SCIENCECITY(GUANGZHOU)INVESTMENTGROUPCO.,LTD、JiangmenHightechndustrialParkCo.,Ltd.、AnhuiConhMaterial TechnologyCo.,Ltd.、ANHUICONCHCEMENTCOMPANYLIMITED、BrainAurora MedicalTechnologyLimited、SICHUANJINYUFINANCING GUARANTEECO.,LTD.、TIANCHANGAGRICULTURALDEVELOPMENTCO.,LTD.、Huishang Bank Corporation Limited、Hubei Financing GuaranteeGroupCo.Ltd.、FuzhouDigtalEconomyInvestmentGroupCoLtd、ChongqingXingnongFinancingGuaranteeGroupCotd、 ChongqingSanxiaFinancingGuaranteeGroupCorporation、ChongqingFengduCulturalAndTourismGroupCo,td.、ZejangES(BVl)o Ltd、HangzhouFuyangTransportationDevelopmentInvestmentGroupCo.,Ltd.、SANShuilnternationalDevelopmentCoLtd（BVI）、Jiangsu Jiangyan Economic Development GroupCo.,LTD、Huaiyuan County New Urbanization Construction Co.Ltd、ANHUI XIHUINVESTMENT HOLDINGGROUPCO.,LTD.、Huaibei City ConstructionInvestment Holding Group Company Limited、Quzhou QutongTransportation InvestmentDevelopmentCo.,Ltd.、ChengduWuouIndustrialDevelopmentInvestmentManagementGroupCo.,Ltd.、WenzhouLucheng DistrictStateowedHoldingGrouCod.、SandongingshuoaiDvelopentGoupCotd、MiinteratioaadingCoited、 ZHONGYUAN DAYU INTERNATIONAL(BVI)CO.,LTD.、ZHONGYUAN ASSET MANAGEMENT CO.,LTD、Yichang High-tech Investment DevelopmentCoLtd.ChengduTransportationIvestmentGroupCoLtd.、BinzhouBinchengconomicDevelopmentIvestmentCompany LimitedFuqingState-ownedAssetsOperationIvestmentGroupCo.td.、HuaiuanCountyNwUrbanzationConstructionCo.Ltd、HUSHANG BANK、JUNFENG INTERNATIONALCO.,LTD、YANTAIGUOFENG INVESTMENT HOLDINGS GROUPCO.,LTD、JINAN HI-TECHHOLDING GROUPCO.,LTD.、Luoyang Guosheng nvestment Holding GroupCo.,Ltd.、CHINAMINSHENG BANKING、CHANGDECAIXINFINANCING GUARANTEE CO.,LTD.、HUNANRUIXIN INDUSTRIALOPERATIONMANAGEMENTCO.,LTD.、Ganzhou UrbanInvestment Holding Group Co,Ltd.、BANKOFJANGSUFujanJinjangConstructionIvestmentHoldingGoupCo.,Ltd.、MluoRiverHoldingGroupimited、ChinaCinda 2020IManagementLtd、BANKOFNANJING、ZiboCityAssetOperationGroupCo.Ltd、ZhongyuanZhichengCo.Ltd.、ZhongyuanYuzi Investment Holding Group Co.，Ltd.、BANKOFJIUJIANG、JINAN SHIZHONG FINANCE INVESTMENT GROUP CO.,LTD、ZHENGJIN FINANCIALINTERNAlONAL(BVI)CO.LIMTED、ShenghailnvestmentCo.,Limited、CoastalEmeraldLimited、Shandong HiSpeedGroupCo, Ltd.、QINGDAO MILITARY-CIVILIAN INTEGRATION DEVELOPMENT GROUP CO.,LTD.有投资银行业务关系。

# 使用本研究报告的风险提示以及法律声明

兴业证券股份有限公司经中国证券监督管理委员会批准，已具备证券投资咨

，本公司不会因接收人收到本报告而视其为客尸。本报告中的信息、意见等均仅供客户参考，不构成所述证券买卖的出价或征价邀请或要约，投资者自主作出投资决策并自行承担投资风险，任何形式的分享证券投资收益或者分担证券投资损失的书面或口头承诺均为无效，任何有关本报告的摘要或节选都不代表本报告正式完整的观点，一切须以本公司向客户发布的本报告完整版本为准。该等信息、意见并未考虑到获取本报告人员的具体投资目的、财务状况以及特定需求，在任何时候均不构成对任何人的个人推荐。客户应当对本报告中的信息和意见进行独立评估，并应同时考量各自的投资目的、财务状况和特定需求，必要时就法律、商业、财务、税收等方面咨询专家的意见。对依据或者使用本报告所造成的一切后果，本公司及/或其关联人员均不承担任何法律责任。

本报告所载资料的来源被认为是可靠的，但本公司不保证其准确性或完整性，也不保证所包含的信息和建议不会发生任何变更。本公司并不对使用本报告所包含的材料产生的任何直接或间接损失或与此相关的其他任何损失承担任何责任。

本报告所载的资料、意见及推测仅反映本公司于发布本报告当日的判断，本报告所指的证券或投资标的的价格、价值及投资收入可升可跌，过往表现不应作为日后的表现依据；在不同时期，本公司可发出与本报告所载资料、意见及推测不一致的报告；本公司不保证本报告所含信息保持在最新状态。同时，本公司对本报告所含信息可在不发出通知的情形下做出修改，投资者应当自行关注相应的更新或修改。

除非另行说明，本报告中所引用的关于业绩的数据代表过往表现。过往的业绩表现亦不应作为日后回报的预示。我们不承诺也不保证，任何所页示的回报会得以实现。分析中所做的回报预测可能是基于相应的假设。任何假设的变化可能会显著地影响所预测的回报。

本公司的销售人员、交易人员以及其他专业人士可能会依据不同假设和标准、采用不同的分析方法而口头或书面发表与本报告意见及建议不一致的市场评论和/或交易观点。本公司没有将此意见及建议向报告所有接收者进行更新的义务。本公司的资产管理部门、自营部门以及其他投资业务部门可能独立做出与本报告中的意见或建议不一致的投资决策。

本报告并非针对或意图发送予或为任何就发送、发布、可得到或使用此报告而使兴业证券股份有限公司及其关联子公司等违反当地的法律或法规或可致使兴业证券股份有限公司受制于相关法律或法规的任何地区、国家或其他管辖区域的公民或居民，包括但不限于美国及美国公民（1934年美国《证券交易所》第15a-6条例定义为本「主要美国机构投资者」除外）。

本报告由受香港证监会监察的兴证国际证券有限公司(香港证监会中央编号：AYE823)于香港提供。香港的投资者若有任何关于本报告的问题请直接联系兴证国际证券有限公司的销售交易代表。本报告作者所持香港证监会牌照的牌照编号已披露在报告首页的作者姓名旁。本报告的版权归本公司所有。本公司对本报告保留一切权利。除非另有书面显示，否则本报告中的所有材料的版权均属本公司。未经本公司事先书面授权，本报告的任何部分均不得以任何方式制作任何形式的拷贝、复印件或复制品，或再次分发给任何其他人，或以任何侵犯本公司版权的其他方式使用。未经授权的转载，本公司不承担任何转载责任。

# 特别声明

在法律许可的情况下，兴业证券股份有限公司可能会持有本报告中提及公司所发行的证券头寸并进行交易，也可能为这些公司提供或争取提供投资银行业务服务。因此，投资者应当考虑到兴业证券股份有限公司及/或其相关人员可能存在影响本报告观点客观性的潜在利益冲突。投资者请勿将本报告视为投资或其他决定的唯一信赖依据。

# 兴业证券研究

<table><tr><td>上海</td><td>北京</td></tr><tr><td>地址：上海浦东新区长柳路36号兴业证券大厦15层 邮编：200135</td><td>地址：北京市朝阳区建国门大街甲6号世界财富大厦32层01-08单元 邮编：100020</td></tr><tr><td>邮箱：research@xyzq.com.cn</td><td>邮箱：research@xyzq.com.cn</td></tr><tr><td>深圳</td><td>香港 (兴证国际）</td></tr><tr><td>地址：深圳市福田区皇岗路5001号深业上城T2座52楼</td><td>地址：香港德辅道中199号无限极广场32楼全层</td></tr><tr><td>邮编：518035 邮箱：research@xyzq.com.cn</td><td>邮编：518035 邮箱：ir@xyzq.com.hk</td></tr></table>